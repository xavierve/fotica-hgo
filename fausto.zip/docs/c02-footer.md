# c02 — FOOTER (parcial común, Hugo: `layouts/partials/footer.html`)

*(Actualiza el parcial c02 definido en textos-fausto — incorpora los alias oficiales de sede acordados con el cliente: **Fausto Avenida** y **Fausto Duque**)*

---

## ESTRUCTURA — 3 columnas + colofón

### c02.1 — Marca

- Logo Ópticas Fausto
- Tagline: **Evaluamos y cuidamos tu salud ocular y auditiva.**
- Segunda línea (opcional): *En Torre del Mar desde 1982.*

### c02.2 — Fausto Avenida

**Fausto Avenida**
*(iconos SVG en lugar de las palabras "Teléfono", "Email", "Ubicación")*

- 📍 Av. Andalucía, 84 B · Torre del Mar (Málaga) → enlace a Google Maps del centro
- 📞 (+34) 952 54 09 64 → `tel:+34952540964`
- ✉️ info@opticafausto.com → `mailto:info@opticafausto.com`

### c02.3 — Fausto Duque

**Fausto Duque**

- 📍 C/ Duque de Ahumada, 1C · Torre del Mar (Málaga) → enlace a Google Maps del centro
- 📞 (+34) 952 54 70 90 → `tel:+34952547090`
- 💬 WhatsApp: +34 717 77 00 90 → `https://wa.me/34717770090`

*(El WhatsApp común se muestra en esta columna para equilibrar visualmente las dos sedes; alternativa: fila común bajo ambas columnas.)*

### Navegación y RRSS

*(Según ap7.0c, la navegación principal + iconos FB/IG pueden ir como cuarta columna o integrarse sobre el colofón, según resuelva el diseño)*

- INICIO · NOSOTROS · VISIÓN · AUDICIÓN · CONTACTO
- Iconos: Facebook → https://www.facebook.com/OpticaFaustoTorreDelMar/ · Instagram → https://www.instagram.com/opticasfausto/

### Colofón

© {{ now.Year }} Ópticas Fausto · [Aviso Legal](/aviso-legal/) · [Política de Cookies](/politica-de-cookies/)

*(En Hugo el año sale de `{{ now.Year }}` en build — no requiere el JS de año actual previsto en ap7.0c; si se prefiere año vivo entre despliegues, mantener el snippet JS.)*

---

## NOTAS DE IMPLEMENTACIÓN (Hugo)

- **Datos centralizados:** definir sedes en `data/sedes.yaml` (alias, dirección, tel, maps_url) y renderizar las columnas con un `range` — así los alias y NAP viven en un único sitio para footer, página de contacto y Schema.
- **NAP idéntico en todo el sitio:** el formato de dirección y teléfono del footer debe coincidir carácter a carácter con 4.0 Contacto, 1.0 Nosotros y ambos Google Business Profile.
- **Alias en GBP:** valorar renombrar los perfiles de Google Business a "Fausto Avenida" / "Fausto Duque" (o incluirlos como aliases) para consolidar la denominación en Maps y reseñas.
- Teléfonos y direcciones clicables también en el footer (requisito ap8.1): `tel:`, `wa.me`, `mailto:` y enlace a Maps.
- Accesibilidad: iconos SVG con `aria-label` ("Teléfono", "Email", "Ubicación", "WhatsApp") ya que sustituyen al texto.
- Horario en footer (opcional, recomendable): una línea común "L–V 10:00–13:30 · 17:00–20:30" ⚠️ pendiente de confirmar sábados/temporada.

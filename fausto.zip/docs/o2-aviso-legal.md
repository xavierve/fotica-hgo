# o2 — AVISO LEGAL Y POLÍTICA DE PRIVACIDAD (`/aviso-legal/`)

---

## OBJETIVO

Página de cumplimiento (LSSI-CE + RGPD), no de posicionamiento. Da soporte legal al formulario de contacto (la Política de Privacidad enlazada desde su checkbox vive aquí, sección C) y transmite una señal indirecta de confianza: un negocio que explica con claridad qué hace con tus datos es coherente con la marca Fausto.

**Nota de slug (decisión confirmada):** la Política de Privacidad queda **unificada** en esta página como sección C. El checkbox del formulario (4.0) y el footer enlazan a `/aviso-legal/`. Los slugs `/privacidad/` (v07) y `/politica-privacidad/` (v10) quedan descartados — no crear esas URLs ni referenciarlas.

## REQUISITOS TÉCNICOS

- Indexable (sin `noindex`): es señal de transparencia y algunos usuarios la buscan; sin esfuerzo SEO adicional.
- Excluir del `sitemap.xml` o asignar prioridad mínima.
- Enlazada desde el colofón del footer en todo el sitio.
- **Ofuscación frontend del CIF y domicilio via JS** (ver TO DO proyecto-fausto-v09): el texto se publica con datos reales; la ofuscación es capa técnica anti-scraping en implementación, no cambio de contenido.

## META TITLE

`Aviso Legal y Política de Privacidad | Ópticas Fausto`

## META DESCRIPTION

`Información legal, condiciones de uso y política de privacidad del sitio web de Ópticas Fausto, Torre del Mar.`

---

# CONTENIDO COMPLETO

**Breadcrumb:** Inicio → Aviso Legal

**H1:** Aviso Legal

Esta página web es propiedad de **Ana Isabel Santaolalla Gámez**, con CIF *[ofuscado en frontend]* y domicilio en Duque de Ahumada, 1C, Torre del Mar (29740), Málaga.

Para cualquier consulta o propuesta, contacta con nosotros en info@opticafausto.com.

Esta página web se rige por la normativa aplicable en España, quedando sometidos a ella tanto los usuarios nacionales como extranjeros que la utilicen.

El acceso a nuestra página web es gratuito y está condicionado a la previa lectura y aceptación íntegra de las presentes Condiciones Generales de Uso. Al utilizar este portal, sus contenidos o servicios, el usuario acepta y se somete expresamente a estas condiciones. Si no estás de acuerdo, te pedimos que te abstengas de utilizar este sitio.

Podemos modificar en cualquier momento la presentación y configuración de la web, ampliar o reducir servicios, o incluso suprimirla, de forma unilateral y sin previo aviso.

## A. Propiedad intelectual

**H2:** Propiedad intelectual

Todos los contenidos, textos, imágenes, marcas y código fuente de esta web son propiedad de Ópticas Fausto o de terceros de los que se han adquirido los derechos de explotación correspondientes, y están protegidos por la normativa de Propiedad Intelectual e Industrial.

El usuario tiene derecho a un uso privado y sin ánimo de lucro de estos contenidos, necesitando autorización expresa para modificarlos, reproducirlos, explotarlos o distribuirlos.

## B. Condiciones de acceso

**H2:** Condiciones de acceso

El acceso a esta web es gratuito y no requiere registro previo. El envío de datos personales a través del formulario de contacto implica la aceptación expresa de nuestra Política de Privacidad (sección C).

El usuario debe acceder a esta web conforme a la buena fe y a las normas de orden público, siendo responsable de los daños y perjuicios que pudiera causar a terceros o a nosotros mismos por un uso indebido.

No nos hacemos responsables del contenido de páginas web de terceros a las que se pueda acceder mediante enlaces desde esta web.

## C. Política de privacidad

**H2:** Política de privacidad

La confidencialidad y la seguridad de tus datos son un compromiso firme de Ópticas Fausto. Esta sección explica de forma clara cómo tratamos los datos personales que nos facilitas.

**H3: 1. Responsable del tratamiento**

Ana Isabel Santaolalla Gámez (ver datos en el encabezamiento de este Aviso Legal).

**H3: 2. Finalidad, legitimación y conservación de los datos enviados a través del formulario de contacto**

- **Finalidad:** responder a tu solicitud de información o consulta. No utilizamos el formulario de contacto para enviarte comunicaciones comerciales salvo que lo solicites expresamente por otro medio.
- **Legitimación:** tu consentimiento, al enviar el formulario.
- **Conservación:** una vez resuelta tu consulta, tus datos se conservan únicamente el tiempo necesario para gestionarla, salvo que exista una obligación legal de conservación mayor.

El suministro de datos personales requiere una edad mínima de 14 años, o disponer de capacidad jurídica suficiente. Si no nos facilitas los datos solicitados (nombre, teléfono y mensaje), no podremos atender tu consulta.

**H3: 3. Destinatarios de tus datos**

Tus datos se transmiten de forma cifrada a través de un proveedor de envío de correo electrónico (**Resend**), que actúa como encargado del tratamiento exclusivamente para hacernos llegar tu mensaje, y que no los almacena de forma permanente. No cedemos tus datos a ningún otro tercero, salvo obligación legal.

**H3: 4. Derechos en relación con tus datos personales**

Puedes ejercer en cualquier momento tu derecho a:

- Acceder a tus datos personales o solicitar su rectificación si son inexactos.
- Solicitar su supresión cuando ya no sean necesarios para la finalidad por la que fueron recogidos.
- Solicitar la limitación de su tratamiento en determinadas circunstancias.
- Oponerte al tratamiento de tus datos.
- Solicitar la portabilidad de tus datos, cuando aplique.

Para ejercer estos derechos, escribe a info@opticafausto.com indicando la referencia "Datos Personales" y especificando el derecho que deseas ejercer. Si tienes alguna discrepancia con el tratamiento de tus datos, puedes presentar una reclamación ante la Agencia Española de Protección de Datos (www.aepd.es).

**H3: 5. Seguridad de tus datos personales**

Hemos adoptado las medidas técnicas y organizativas necesarias para garantizar la seguridad de los datos personales que nos facilitas, evitando su alteración, pérdida o acceso no autorizado.

**H3: 6. Actualización de tus datos**

Para mantener tus datos actualizados, te pedimos que nos informes si se produce alguna modificación en ellos. Esta Política de Privacidad puede actualizarse para adaptarse a cambios en la web o en la normativa aplicable.

## D. Responsabilidades

**H2:** Responsabilidades

Ofrecemos esta web con la máxima diligencia posible, tanto en el servicio como en los medios tecnológicos utilizados. No obstante, no nos responsabilizamos de la presencia de virus u otros elementos que puedan dañar el sistema informático del usuario, ni garantizamos una disponibilidad continua e ininterrumpida del servicio.

Queda prohibida cualquier acción que origine una sobrecarga en nuestros sistemas informáticos, así como la introducción de virus o software que altere el funcionamiento normal de esta web.

El usuario asume la responsabilidad derivada del uso de esta página web y reconoce haber entendido y aceptado las presentes condiciones de uso.

## E. Cookies

**H2:** Cookies

El uso de cookies en este sitio web se regula en nuestra [Política de Cookies](/politica-de-cookies/), donde se detalla qué cookies se utilizan y con qué finalidad. Actualmente este sitio no utiliza cookies de análisis, personalización ni publicidad; si en el futuro se incorporan, dicha política se actualizará y se solicitará el consentimiento previo del usuario conforme a la normativa vigente.

---

## ENLAZADO INTERNO

- Entrante: colofón del footer (todo el sitio) + checkbox RGPD del formulario (4.0).
- Saliente: /politica-de-cookies/ (referencia cruzada recomendable entre ambas legales) y aepd.es (externo, `rel="nofollow"` opcional).

## SCHEMA RECOMENDADO

- **WebPage** simple + **BreadcrumbList** (Inicio → Aviso Legal). Sin más marcado: no aporta.

## NOTAS

- Texto legal mantenido íntegro de la versión v10 (ya revisada); solo se ha añadido jerarquía H2/H3 para legibilidad y accesibilidad, y la nota de slug pendiente.
- ⚠️ Confirmar con el cliente: el CIF real para el desarrollo (se publica ofuscado por JS pero debe ser correcto) y la decisión sobre página de privacidad separada o unificada.

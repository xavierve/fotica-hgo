# o3 — POLÍTICA DE COOKIES (`/politica-de-cookies/`)

---

## OBJETIVO

Cumplimiento LSSI-CE/RGPD para la **Fase 1: sitio sin cookies de terceros** — sin analítica, sin píxeles, sin banner de consentimiento (no hay nada que consentir). La página documenta esa situación con transparencia, que además es un pequeño argumento de marca: una web sin rastreadores es coherente con "aquí no eres un número".

**Nota de slug:** la estructura v07 usaba `/privacidad/`; v10 lista `/politica-privacidad/`. Dado que la privacidad vive en `/aviso-legal/` (sección C), propongo `/politica-de-cookies/` para esta página, que es lo que realmente contiene. **Confirmar slug definitivo** y reflejarlo en footer y sitemap.

## REQUISITOS TÉCNICOS

- Indexable, excluida del sitemap o con prioridad mínima.
- Enlazada desde el colofón del footer en todo el sitio.
- **Fase 2 (documentada en ap11/TO DO):** al activar SEM/Meta Ads o analítica, esta política se amplía con la tabla de cookies (titular, finalidad, duración) y se implementa el consentimiento previo con aceptación granular. El bloque "Si en el futuro…" de esta página ya deja preparado ese aviso.
- **Criterio de fricción mínima (decisión del proyecto):** ni en Fase 1 ni en Fase 2 se usará modal bloqueante. Fase 1: sin banner de ningún tipo (no hay nada que consentir). Fase 2: el consentimiento previo es obligatorio, pero se implementará como **barra inferior no intrusiva** — no tapa contenido, no impide navegar ni llamar — con botones Aceptar / Rechazar / Configurar equivalentes en visibilidad (requisito AEPD: rechazar tan fácil como aceptar), y los píxeles cargando **solo tras la aceptación**. Coherente con el principio de diseño "sin modales ni pop-ups" (ap8.1).

## META TITLE

`Política de Cookies | Ópticas Fausto`

## META DESCRIPTION

`Esta web no utiliza cookies de análisis, personalización ni publicidad. Conoce nuestra política de cookies.`

---

# CONTENIDO COMPLETO

**Breadcrumb:** Inicio → Política de Cookies

**H1:** Política de Cookies

**Responsable:** Ana Isabel Santaolalla Gámez, con domicilio en C/ Duque de Ahumada, 1C, 29740 Torre del Mar (Málaga).

## ¿Qué es una cookie?

**H2:** ¿Qué es una cookie?

Una cookie es un pequeño archivo que un sitio web puede guardar en tu navegador para recordar información sobre tu visita. Algunas cookies son necesarias para que la web funcione correctamente; otras se usan para analizar el comportamiento de los usuarios o para mostrar publicidad personalizada.

## Cookies que utiliza este sitio

**H2:** Cookies que utiliza este sitio

**Actualmente, esta web no utiliza cookies de análisis, personalización ni publicidad.** No instalamos Google Analytics, píxeles de Meta/Facebook, ni ningún sistema de seguimiento de terceros. Por este motivo, no verás un banner de consentimiento de cookies: no hay nada que requiera tu autorización previa.

El sitio puede utilizar cookies técnicas estrictamente necesarias para su funcionamiento básico (por ejemplo, para recordar tu elección si rechazas o aceptas futuras cookies, cuando estas se incorporen). Estas cookies técnicas no requieren consentimiento según el artículo 22.2 de la LSSI-CE, al ser indispensables para prestar el servicio solicitado.

## Si en el futuro se incorporan cookies

**H2:** Si en el futuro se incorporan cookies

Si en algún momento Ópticas Fausto decide activar campañas de publicidad en Google Ads o Meta (Instagram/Facebook Ads) con seguimiento de conversiones, o herramientas de analítica web, esta Política de Cookies se actualizará para detallar qué cookies se instalan, su finalidad, duración y titular, y se incorporará un banner de consentimiento previo a la carga de dichas cookies, permitiendo al usuario aceptarlas, rechazarlas o configurarlas de forma granular, conforme a la normativa vigente (RGPD y LSSI-CE).

## Cambios en esta política

**H2:** Cambios en esta política

Esta Política de Cookies puede modificarse para adaptarse a cambios en el sitio web o a nuevas exigencias legislativas. Cuando se produzcan cambios significativos, se comunicará al usuario en esta misma página.

---

## ENLAZADO INTERNO

- Entrante: colofón del footer (todo el sitio).
- Saliente: /aviso-legal/ (referencia cruzada entre legales).

## SCHEMA RECOMENDADO

- **WebPage** simple + **BreadcrumbList** (Inicio → Política de Cookies).

## NOTAS

- Texto mantenido de v10 con jerarquía de encabezados añadida.
- Sugerencia de marca (opcional, validar con cliente): una línea final en tono Fausto — *«En resumen: navega tranquilo. Aquí ni te seguimos ni te perfilamos — preferimos conocerte en persona.»* Humaniza la página legal y conecta con la promesa de marca; si se prefiere sobriedad total, omitir.

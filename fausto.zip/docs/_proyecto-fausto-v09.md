# Proyecto Web — Ópticas Fausto

Contexto base: Soy desarrollador web con experiencia en código HTML/CSS, algo JS y PHP, habilidades WP.

Tengo un nuevo cliente que tiene web anterior y la quiere mejorar.

Tiene Wordpress basee 
https://www.opticafausto.com/
con 4 landing pages
https://audicion.opticafausto.com/
https://lentes-graduadas.opticafausto.com/
https://lentillas.opticafausto.com/
https://vueltaalcole.opticafausto.com/
---
## ap1. Objetivos

Crear sitio web estático, rediseño desde el sitio anterior (WordPress de otro desarrollador)

Tomar el texto antiguo como base [ver 4.Assets], para re elaborar dentro de la Estrategia. 

Posibilidad de mantener las imágenes, que también tengo  [ver 4.Assets]

Haremos cambios en estructura  [ver 5. Estructura]


## ap2. Visión del proyecto

Ópticas Fausto es un negocio local que ofrecer productos y servicios de óptica y Audición en Torre del Mar (Vélez-Málaga), donde tiene 2 sedes y una gran reputación en sus 44 años de trayectoria (apertura 1982).
Es una empresa familiar que destaca por la atención personalizada al cliente, tanto a residentes como a turistas de habla inglesa y alemana. Esto lo hace destacar frente a tantas otras tiendas de franquicias, que lucen más atractivas en sus amplios locales pero no cuentan con la sincera cercanía al cliente.

La Estrategia principal es incidir en la reputación de Fausto y diferenciarse de las grandes Franquicias por atención, reputación, y Seguimiento de las necesidades del cliente.

Este sitio web tiene como objetivos:
1. Ganar posicionamiento SEO (personalización de Metadatos, Open Graphics, Schema, contenidos largos con FAQ, etc)
2. **Convertir visitas digitales en visitas físicas o llamadas telefónicas**
3. Diferenciárse con claridad de las franquicias ópticas nacionales.
4. Prepararse para SEM, con algunas páginas funcionando también como landing.

---

## ap3. Público objetivo

| Perfil | Características clave |
|---|---|
| Residente local (45–75 años) | Conoce la marca, busca refuerzo de confianza y comodidad digital |
| Turista extranjero (65+ años) | Principalmente anglófono; puede necesitar atención urgente de visión o audición durante su estancia |
| Persona mayor (75+) | Poca familiaridad tecnológica; necesita claridad absoluta, texto grande y CTA directa |

---

## ap4. Posicionamiento de marca

- **Tono:** cálido, cercano y profesional. Como hablar con un especialista de confianza, no con una corporación.
- **Diferenciación clave:** 44 años de historia local (1982–2026), caras conocidas (continuidad familiar y de equipo, frente a la rotación de personal de las franquicias). Conocimiento del cliente y seguimiento de sus necesidades a lo largo del tiempo.
- **Promesa de valor:** «Nos conocemos de toda la vida. Y eso se nota.»
- **Frase de atención (sustituye a "atención personalizada"):** «Atención humana, de quien quiere conocerte y seguirá atendiéndote durante años.»
- **Idiomas:** archivado por ahora (ver ap9). No se desarrolla copy en inglés ni alemán en esta fase.

### ap4.1 Mensaje por audiencia

Tres públicos con motivaciones distintas (ver ap3) requieren matices de mensaje, no solo de idioma. Se propone un **slider o banner rotativo en el Hero de Inicio** (y opcionalmente en Visión/Audición) con 2-3 variantes de mensaje que el usuario puede ver pasar, sin necesidad de detectar quién es:

| Variante | Público al que apela | Mensaje |
|---|---|---|
| Confianza / continuidad | Residente local (45-75) | «Nos conocemos de toda la vida. Y eso se nota.» |
| Cercanía cotidiana | Persona mayor (75+) | «Aquí no eres un número de cita. Eres Anabel, Pepe, María… y lo sabemos.» |
| Servicio sin complicaciones | Turista / visitante | «¿Problema de vista o de oído durante tus vacaciones? Atención rápida, sin cita previa.» |

Implementación sugerida: rotación automática cada 5-6 segundos con pausa al hover/touch, sin afectar al CTA fijo (que permanece igual en las tres variantes). Alternativa más simple si se prefiere evitar JS adicional en el hero: bloque estático con las tres frases una debajo de otra a modo de "para quién es esto", sin necesidad de slider.

---

## ap5. Assets

### ap5.1 Imágenes 
Imagenes-originales.zip
Son las de la web anterior, nombradas con prefijo numérico: 212-blabla.jpg = página 2.1.2. Logos con prefijo 0000
Veremos si mantener todas o algunas. 
Espero nuevas fotos de las tiendas

### ap5.2 Textos
fausto-textos-originales.md
son los textos de cada página de la web previa, con la estructura antigua.
Debemos revisar y mejorarlos junto a Claude.

### ap5.3 Contacto

Común a ambas tiendas: 
Móvil/WhatsApp +34 717 77 00 90 +34717770090
Email: info@opticafausto.com

Fausto I
Ubicación: Avd. Andalucía, 84B · Torre del Mar (Málaga)
Tel: +34 952 54 09 64

Fausto II
Ubicación: C/ Duque de Ahumada, 1C · Torre del Mar (Málaga)
Tel: +34 952 54 70 90

Horarios de apertura (ambos locales)
10:00–13:30
17:00–20:30
---

## ap6. Estructura del sitio

0.0 Inicio
1.0 Nosotros
2.0 Visión (landing) 
	-- 2.1 Visión  / Servicios /
		--- 2.1.1 Optometría
        --- 2.1.2 Visión Infantil
        --- 2.1.3 Control de Miopía
        --- 2.1.4 Baja Visión
        --- 2.1.5 Visión +40
        --- 2.1.6 Terapia Visual
	-- 2.2 Visión / Productos / 
		--- 2.2.1 Lentes Oftálmicas
		--- 2.2.2 Gafas Progresivas
		--- 2.2.3 Lentes de Contacto
		--- 2.2.4 Filtros solares y luz azul
		--- 2.2.5 Ayudas Visuales
		--- 2.2.6 Gafas Infantiles
		--- 2.2.7 Gafas Deportivas
3.0 Audición (landing)
	-- 3.1 Audición / Servicios  /
            --- 3.1.1 Audiometría
			--- 3.1.2 Adaptación de audífonos en adultos y niños
            --- 3.1.3 Tinnitus
            --- 3.1.4 Mantenimiento de audífonos
            --- 3.1.5 Rehabilitación auditiva 
	-- 3.2 Audición / Productos / 
            --- 3.2.1 Audífonos
            --- 3.2.2 Ayudas Auditivas
            --- 3.2.3 Protectores a medida

4.0 Contacto
-
o1 404 personalizada
o2 Asiso Legal
o3 Política de privacidad

NOTA: 2.1 , 2.2, 3.1 y 3.2 no son páginas sino carpetas que contienen a las páginas del sub-nivel. Las 2.1.x , 2.2.x, 3.1.x y 3.2.x reciben los enlaces desde 2.0 y 3.0, donde aparecen listadas como cards / blog posts lists de Servicios o de Productos.

### Slugs
/
/nosotros/
/vision/
/vision/servicios/optometria/
/vision/servicios/vision-infantil/
/vision/servicios/control-miopia/
/vision/servicios/baja-vision/
/vision/servicios/vision-40/
/vision/servicios/terapia-visual/
/vision/productos/lentes-oftalmicas/
/vision/productos/gafas-progresivas/
/vision/productos/lentes-de-contacto/
/vision/productos/filtros/
/vision/productos/ayudas-visuales/
/vision/productos/gafas-infantiles/
/vision/productos/gafas-deportivas/
/audicion/
/audicion/servicios/audiometria/
/audicion/servicios/adaptacion-audifonos/
/audicion/servicios/tinnitus/
/audicion/servicios/rehabilitacion-auditiva/
/audicion/servicios/mantenimiento-audifonos/
/audicion/productos/audifonos/
/audicion/productos/ayudas-auditivas/
/audicion/productos/protectores-a-medida/
/contacto/
/aviso-legal/
/privacidad/
/404 → (no es carpeta, es página especial)

---

## ap7. Descripción de cada sección

### ap7.0a Navegador principal

INICIO, NOSOTROS, VISIÓN, AUDICIÓN, CONTACTO

### ap7.0b Header

Logo a izquierda y Navegador a derecha (hamburguer en mobile

### 7.0c Footer

- En FOOTER principal van 3 columnas: 
1. Opticas Fausto. Con logo y párrafo
2. Navegación principal y link RRSS (iconos FB e IG)
3. Contacto. Teléfonos y direcciones por sede, con clics activos a llamada, WhatsApp (en móvil) y Ubicación (google maps)
- El colofón: 
Copyright Opticas Fausto (+ javascript año actual)  
Ver dónde añadir:
- Aviso Legal
- Política de privacidad

### ap7.0c Página 404 personalizada
- Mensaje amable con acceso rápido a las secciones principales y al teléfono.


### ap7.1 (page id ) Inicio (`/`)

**Propósito:** crear impacto inmediato y dirigir al usuario a visión, audición o CTA directo.

**Contenido:**
- Hero con titular de 44 años y tagline de confianza. Foto del equipo real en tienda (no imágenes de stock).
	La importancia de la confianza a la hora de confiar el cuidado de la visión y la audición.
- Bloque de mensaje por audiencia (slider o banner, ver ap4.1): rotación de 2-3 frases que apelan a residente, persona mayor y turista, sin necesidad de que el usuario se identifique.
- Features y Why Us: para fortalecer la conversión, mostrando las diferencias en la atención humana y profesional frente a la de las franquicias.
- Banner CTA: «Si entras en Fausto, lo más probable es que Anabel o Leito ya sepan que llevas progresivos desde hace tres años.»
- Párrafo de diferenciación vs. franquicias (ver desarrollo de copy en textos-fausto-v09): contraste directo entre el modelo de equipo fijo y seguimiento de Fausto frente a la rotación de personal y trato estandarizado de las franquicias ópticas nacionales.
- Elección interés: Dos bloques de entrada grandes: **Visión** [6.2] y **Audición** [6.3] y un tagline de cada una,para dirigir al cliente en forma sencilla hacia soluciones de visión o de audición.
Ejemplos:
	Visión. <<Recupera la alegría de los detalles>>
	Audición. <<Vuelve a oir bien y conectar>>
- Franja de confianza: años de experiencia (44), número de clientes atendidos, 2 locales, empresa familiar desde 1982. Atención humana, de quien quiere conocerte y seguirá atendiéndote durante años.
- Testimonios reales de clientes (3–4 citas breves), reforzando la idea de continuidad y trato cercano frente a franquicias.
- CTA fija: número de teléfono visible en header y sticky en móvil con icónos (llamada, WhatsApp, Ubicación).
- FAQ  Pregunta frecuentes (FAQ)
- ¿Necesito cita previa?
- ¿Cuánto tarda una revisión visual?
- ¿Tienen servicio en inglés? 
- ¿Tienen servicio en alemán? 
- ¿Aceptan seguros médicos?
- ¿Pueden reparar mis gafas en el día?
- ¿Cuánto dura la prueba de audífono?

---

### ap7.2 (page id 2.0) Visión — Landing (`/vision`)

Página paraguas que presenta el área de visión. Incluye acceso visual a servicios y productos, breve presentación del equipo óptico y un CTA para pedir cita.

Se presentan los SERVICIOS y PRODUCTOS como si fuera una lista de posts de una categoría de un blog. Una Card con una imagen, título, Descripción y enlace a la página

#### ap7.2.1 Servicios de Visión (`/vision/servicios`)
No es una página en sí, sino una carpeta que contiene páginas a la 	que se accede desde 6.2

| Page Id |Page Name | Contenido clave |
|---|---|---|
| 2.1.1 | Exámenes visuales | Qué incluye la revisión, frecuencia recomendada, sin cita previa o con cita |
| 2.1.2 | Visión infantil | Cuándo llevar al niño, señales de alerta, revisiones escolares |
| 2.1.3 | Control de Miopía | Explicación accesible, indicaciones, sesiones |
| 2.1.4 | Baja visión | A quién va dirigido, ayudas disponibles, derivaciones |
| 2.1.5 | Visión +40 | Explicación accesible, indicaciones, sesiones |
| 2.1.6 | Terapia visual | Explicación accesible, indicaciones, sesiones |

#### ap7.2.2 Productos de Visión (`/vision/productos`)
No es una página en sí, sino una carpeta que contiene páginas a la 	que se accede desde 6.2

| Page Id |Page Name | Contenido clave |
|---|---|---|
| 2.2.1 | Lentes Oftalmológicas | Tipos, calidades, materiales, marcas |
| 2.2.2 | Gafas Progresivas | Tipos, calidades, materiales, marcas |
| 2.2.3 | Lentillas - Lentes de Contacto | Diarias, mensuales, tóricas, cosméticas; cuidado y mantenimiento |
| 2.2.4 | Filtros solares y luz azul | asset |
| 2.2.5 | Ayudas visuales | Lupas, telescopios, filtros; para quién son útiles |
| 2.2.6 | Gafas infantiles | Monturas resistentes, garantía, importancia de la corrección temprana |
| 2.2.7 | Gafas deportivas | Deportes habituales en la zona (náutica, ciclismo, pádel), normativa |

#### Funcionarán también como landing

- page id 2.2.2 Lentes Progresivas 
- page id 2.2.3 Lentillas 
- page id 2.2.6 Gafas infantiles

Estas páginas de productos tendrán mayor impacto visual y de contenidos ya que seráh utilizada para campañas de publicidad. Funcionando así también como landing.

Más contenidos de textos. 
Textos destacados 
Preguntas frecuentes 

Parte de los contenidos se señalan en el documento de textos originales.
---

### ap7.3 (page id 3.0) Audición — Landing (`/audicion`)

Página paraguas del área auditiva. Presentación del edquipo y especialista, acceso a servicios y productos, y CTA para prueba gratuita de audición.

Se presentan los SERVICIOS y PRODUCTOS como si fuera una lista de posts de una categoría de un blog. Una Card con una imagen, título, Descripción y enlace a la página

#### ap7.3.1 Servicios de Audición (`/audicion/servicios`)
No es una página en sí, sino una carpeta que contiene páginas a la 	que se accede desde 6.2

| Page Id |Page Name | Contenido clave |
|---|---|---|
| 3.1.1 | Audiometría | En qué consiste, duración, resultado, sin derivación médica necesaria |
| 3.1.2 | Adaptación de audífonos | Proceso paso a paso, prueba de audífono gratuita, seguimiento |
| 3.1.3 | Tinitus | qué es y cómo se trata |
| 3.1.4 | Mantenimiento de audífonos | Limpieza, recambios, reparaciones, servicio urgente para turistas |
| 3.1.5 | Rehabilitación auditiva | Qué es, beneficios, complemento al audífono |


#### ap7.3.2 Productos de Audición (`/audicion/productos`)
No es una página en sí, sino una carpeta que contiene páginas a la 	que se accede desde 6.2

| Page Id |Page Name | Contenido clave |
|---|---|---|
| 3.2.1 | Audífonos | tipos, Características, diferencias |
| 3.2.2 | Ayudas Auditivas | asset | 
| 3.2.3 | Protectores a medida | Para música, trabajo, natación, ruido  y de Baño |
---

### ap7.4 (page id 2.0) Nosotros (`/nosotros`)  *(sección recomendada adicional)*

Esta página es el motor de confianza del sitio. Contenido sugerido:

- **Historia:** 44 años en el pueblo (1982-2026), cómo empezó, evolución.
- **El equipo:** fotos reales, nombres, especialidades. Esto diferencia radicalmente de las franquicias.
- **Diferenciación vs. franquicias:** párrafo explícito que contraste el modelo Fausto (mismo equipo desde hace años, seguimiento post-venta, decisiones tomadas por quien te atiende) frente al de una franquicia (rotación de personal, protocolos estandarizados, decisiones centralizadas). Ver desarrollo de copy en textos-fausto-v09.
- **Los dos locales:** direcciones, fotos interiores, horarios.
- **Compromisos:** atención humana, de quien quiere conocerte y seguirá atendiéndote durante años; sin presión de ventas, seguimiento postventa, garantías.
- **Testimonios:** 2-3 citas breves de clientes reales, reforzando continuidad y trato cercano.
- **Certificaciones y pertenencia a colegios profesionales** (si aplica).

---

### ap7.5 (page id 4.0) Contacto (`/contacto`)

- Teléfonos con enlace directo `tel:` (llamada con un toque en móvil).
- Direcciones de los dos locales con enlace a Google Maps.
- Horarios de apertura (incluyendo variaciones de temporada turística).
- Email clicable `mailto:` en footer y página de contacto.
- Mensaje específico para turistas, en español: «Atendemos en inglés y alemán — ven sin cita previa si tienes una urgencia visual o auditiva durante tu estancia.» (el copy nativo en inglés/alemán queda como desarrollo a futuro, ver ap9; mientras tanto se apoya en la traducción automática del navegador).

#### Formulario de contacto

Estrategia dual según dispositivo, con ambas opciones siempre visibles pero con jerarquía visual adaptada:

**Mobile** — CTA principal: botón «Envíanos un email» con enlace `mailto:info@opticasfausto.com?subject=Consulta_OpticzasFausto`. El formulario queda disponible pero colapsado bajo «¿Prefieres escribirnos aquí?».

**Desktop** — Formulario visible por defecto como elemento principal. El email directo aparece como alternativa secundaria bajo el formulario: «O escríbenos a info@opticafausto.com».

#### Backend del formulario

El sitio es estático (Cloudflare Pages, sin PHP). El formulario se procesa mediante un **Cloudflare Worker** que recibe el POST y envía el mensaje vía **Resend** (API transaccional, tier gratuito: 3.000 emails/mes).

Campos del formulario: nombre, teléfono, mensaje breve. Sin campos innecesarios.

**Ventajas de esta solución:**
- Sin terceros que almacenen datos de los usuarios → cumplimiento RGPD simplificado
- Sin sesión ni cookies adicionales
- Mención en Política de Privacidad: «Los datos del formulario se transmiten cifrados y no son almacenados por terceros»
- Coste cero dentro del tier gratuito de Resend

#### Implementación (fase de desarrollo)

1. Crear Worker en Cloudflare Dashboard
2. Configurar cuenta Resend y dominio verificado `opticafausto.com`
3. El Worker recibe POST del formulario, llama a la API de Resend, devuelve confirmación al usuario
4. Mostrar mensaje de confirmación visible tras el envío (no redirigir a otra página)

---

## ap8. Diseño y experiencia de usuario

### ap8.1 Tecnologías

#### dominio
opticasfausto.com será el desarrollo inicial
Cuando tenga control muevo el desarrollo al antiguo opticafausto.com
finalmente opticasfausto.com redirigirá automáticamente a opticafausto.com
 
Los subdominios se redirigirán permanentemente a las nuevas landing que incorporan su contenido. Implementación: redirecciones 301 vía `.htaccess` para las URLs antiguas que desaparezcan dentro del propio dominio; gestión de cabeceras (headers) en Cloudflare Pages para la página 404 y otras rutas que lo requieran.
#### Desarrolo
HTML estático + CSS + JS vanilla ·  Sin CMS

#### Diseño Template HTML/CSS base
Componentes reutilizables (header, footer, nav, cards de servicio/producto, CTA con 2 botones: Llamada directa y WhatsApp directo, CTA)

**Template Base + Mayor impacto visual**
INICIO, VISIÓN, AUDICIÓN, GAFAS GRADUADAS, LENTILLAS, GAFAS INFANTILES
**Template Base**
Nosotros y resto de productos y servicios
**Template Base + Contacto**
Diseño sobre Template y incorporando [ap7.5]


#### Desplieguue
Será desplegado en Cloudflare Pages en nuevo dominio opticasfausto.com .

### ap8.1 Principios de diseño

- mobile first y buenas prácticas de desarrollo HTML (metadata, og, schema, HTML semánico, colores definidos en root, accesibilidad, CSS Crítico inline en home. etc)
- **Legibilidad ante todo:** cuerpo de texto ≥ 18 px, interlineado ≥ 1.6, párrafos cortos. contraste alto (WCAG AA como mínimo)
- **Contraste WCAG AA:** ratio mínimo 4.5:1 para texto normal, 3:1 para texto grande.
- **Navegación sin fricción:** máximo 2 niveles de menú visibles; nada enterrado.
- teléfono, WhatsApp y Location Maps, visibles en sticky footer mobile.
- **Sin modales ni pop-ups:** el público mayor los encuentra confusos y los abandona.
- Accesibilidad
- acabado profesional 
- efectos JS orquestados
- seo por cada página.
- Imágenes y diseño premium que mantengan un hilo narrativo y estilo acorde a la marca.

-  Teléfonos clicables (`tel:`) en header, footer y página de contacto
-  Movil clicables (`https:/wa.me/`) en header, footer y página de contacto
-  Direcciones clicables (link google maps) en footer y página de contacto
-  Email clicables ('mailto:') en footer y página de contacto
-  Todas las imágenes con texto alternativo (`alt`) en ES y EN
-  Formulario de contacto probado y con confirmación visible
-  Política de privacidad y aviso de cookies publicados
-  Prueba en móvil iOS y Android (Chrome y Safari)
-  Prueba de legibilidad: pedir a una persona mayor que navegue sin ayuda
-  Velocidad: puntuación PageSpeed Insights > 85 en móvil


### ap8.2 Paleta cromática sugerida (A DEFINIR)

| Rol | Color | Justificación |
|---|---|---|
| Principal | Verde `#34855B` | Del logo. Identidad de marca: header, enlaces activos, iconografía |
| Secundario | Azul marino profundo `#1B3A5C` | Confianza, profesionalidad, mar mediterráneo |
| Acento | Dorado cálido `#C9A84C` | 44 años, premium sin frialdad |
| Texto | Gris oscuro `#2C2C2C` | Máximo contraste, menos agresivo que negro puro |
| Fondo | Blanco roto `#FAFAF8` | Limpieza sin frialdad clínica |

https://coolors.co/34855b-1b3a5c-c9a84c-2c2c2c

#### Lógica de botones y CTA

El CTA ya no comparte color con el Principal: necesita destacar sobre el resto de la paleta, no fundirse con el header o los enlaces de marca. Se proponen dos variantes de botón con roles distintos:

**Botón CTA primario** (llamada, WhatsApp, "Pide tu cita") — fondo sólido en color de marca (Verde `#34855B` o Azul `#1B3A5C`, a elegir uno como CTA principal del sitio para mantener consistencia) con texto blanco. En hover, transición a un tono ligeramente más oscuro del mismo color o al Acento dorado, para dar feedback visual sin cambiar de familia cromática.

**Botón secundario / outline** (acciones de menor jerarquía: "Ver más", enlaces dentro de cards) — fondo blanco o Fondo `#FAFAF8`, texto en color Verde o Azul (el mismo elegido como CTA primario), borde del mismo color. En hover, transición a fondo Acento dorado o al color de marca sólido con texto blanco (invirtiendo la relación figura-fondo), manteniendo siempre contraste WCAG AA.

Recomendación: fijar **un solo color** (Verde o Azul) como "color de acción" del sitio para que el usuario aprenda rápido qué es clicable, y reservar el segundo color de marca para detalles de identidad (franjas, iconos, fondos de sección) sin función de CTA.

### ap8.3 Tipografía sugerida  (A DEFINIR)

- **Titulares:** Lora (serif elegante, legible, evoca tradición sin ser anticuada)
- **Cuerpo:** Inter o Source Sans 3 (sans-serif muy legible en pantalla)
- **Tamaños mínimos:** H1 → 36 px, H2 → 28 px, cuerpo → 18 px, etiquetas → 14 px

### ap8.4 Elemento diferenciador

**Fotos reales del equipo y los locales en lugar de imágenes de stock.** Es el elemento que más confianza genera y el que ninguna franquicia puede copiar. Invertir en una sesión fotográfica profesional es la mejor inversión para este sitio.
Se añadirán luego, de momento poner otras.
---

## ap9. Idiomas

En esta fase, el sitio se publica solo en español. Se facilita la traducción automática del navegador (sin selector de idioma propio) y se incluye `hreflang="es"` en el `<head>`.

El soporte multilingüe (ES/EN/DE con subpaths y selector en header) no está presupuestado en esta fase y queda como opción a desarrollar en el futuro. No se genera copy nativo en inglés ni alemán por ahora.

Esto no afecta a la atención presencial: Fausto sigue atendiendo a clientes en inglés y alemán en tienda, y esa información se mantiene reflejada en el copy en español (por ejemplo, en las FAQ de Inicio: "¿Tienen servicio en inglés/alemán?").

---

## ap10 SEO y Redes — SEO local

1. **Google Business Profile** de cada local: fotos, horarios, respuestas a reseñas. Es más urgente que el propio sitio web.
2. **Palabras clave principales:** «óptica Torre del Mar», «audífono Torre del Mar», «revisión visual Torre del Mar».
3. **Datos estructurados** (Schema.org): `LocalBusiness`, `MedicalBusiness`, horarios, direcciones.
4. **Meta títulos y descripciones** en español para cada página.
5. **Velocidad:** Google penaliza sitios lentos; las imágenes optimizadas son lo más importante.

### Cookies y publicidad — fases

- **Fase 1 (lanzamiento):** sin cookies de terceros, sin píxeles de tracking (ni Meta Pixel, ni Google Ads conversion tag, ni Analytics). Sin banner de consentimiento, fricción mínima para el usuario.
- **Fase 2 (activación de campañas SEM / Meta Ads):** en el momento en que se instale cualquier píxel de seguimiento o conversión de terceros, será obligatorio añadir un banner de consentimiento de cookies conforme a LSSI-CE/RGPD, antes de cargar dicho píxel. Esta fase debe planificarse junto con el lanzamiento de campañas, no después.

### Schema.org 
lo definiremos para cada página
@graph con entidad raíz Organization (marca Fausto) + dos Optician (uno por local) vinculados vía parentOrganization
Audiología como hasOfferCatalog dentro de cada Optician — sin entidad Audiologist separada
Sin medicalSpecialty (evitar errores Search Console)
Schema de página: Service, Product, ItemList según tipo

### Google Maps Profile
completos

Fausto Avenida
https://share.google/lt3s0XecMBnpr3exH

Fausto Duque
https://share.google/uotnWlZFT0nfpuVoP

### Redes

#### Facebook
https://www.facebook.com/OpticaFaustoTorreDelMar/?locale=es_ES

#### Instagram
https://www.instagram.com/opticasfausto/
---

## ap11. TO DO — pendientes para fases posteriores

*(Apartado solo de uso interno, lectura de Claude y del propietario del proyecto)*

### Cookies y publicidad — activación de Fase 2

Lanzamiento (Fase 1): sin cookies de terceros, sin píxeles, sin banner. La Política de Cookies publicada (ver o03 en textos-fausto-v09) refleja honestamente este estado: "actualmente esta web no utiliza cookies de análisis, personalización ni publicidad".

Cuando se decida activar SEM (Google Ads) o Meta Ads con seguimiento de conversiones, **antes** de instalar cualquier píxel:

1. Añadir banner de consentimiento de cookies (aceptar / rechazar / configurar), conforme a LSSI-CE y RGPD.
2. Actualizar la Política de Cookies (o03) detallando cada cookie instalada: nombre, titular, duración, finalidad y, si aplica, transferencia internacional de datos.
3. Cargar los píxeles de tracking únicamente después de que el usuario haya dado su consentimiento explícito (no antes).
4. Revisar si el formulario de contacto necesita actualizar su checkbox de privacidad para reflejar el nuevo tratamiento (analítica de conversión, etc.).

### Ofuscación de datos sensibles

El CIF y el domicilio particular que aparecen en el Aviso Legal (o02) se publican en texto, tal como exige la normativa, pero deben ofuscarse a nivel de implementación frontend (por ejemplo, renderizado vía JS en cliente, o técnica equivalente) para dificultar el scraping automatizado por bots. Pendiente de desarrollo, no afecta al contenido del texto.

### Idiomas (EN/DE)

Ver ap9. Sin presupuesto en esta fase. La atención presencial en inglés y alemán se mantiene y se menciona en el copy en español (FAQ, Contacto, franja de confianza de Inicio); no hay copy nativo en otros idiomas todavía.

### Redirecciones

- Subdominios antiguos (audicion., lentes-graduadas., lentillas., vueltaalcole.) → 301 permanente a la landing/página nueva que incorpora su contenido. Gestionar vía `.htaccess`.
- Página 404 y otras rutas especiales → gestión vía headers en Cloudflare Pages.
- Dominio: ver ap8.1 (opticasfausto.com en desarrollo → migración a opticafausto.com cuando se tenga control → redirección final opticasfausto.com → opticafausto.com).


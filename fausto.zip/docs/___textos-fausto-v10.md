================================
# PROYECTO PARA TEXTOS BASE WEB OPTICAFAUSTO.COM
============

## INSTRUCCIONES
// Actua como un experto en copy y en marketing, lee y analiza los textos en el contexto del Proyecto Web, añadiendo, modificando o reestructurando los textos de cada página en función de la estrategia y objetivos.

## // REFERENCIA PROYECTO WEB
Ópticas Fausto es un negocio local que ofrece productos y servicios de óptica y audición en Torre del Mar (Vélez-Málaga), donde tiene 2 sedes y una gran reputación en sus 44 años de trayectoria (apertura 1982).
Es una empresa familiar que destaca por la atención personalizada al cliente, tanto a residentes como a turistas de habla inglesa y alemana. Esto lo hace destacar frente a tantas otras tiendas de franquicias, que lucen más atractivas en sus amplios locales pero no cuentan con la sincera cercanía al cliente.
Más de 27.000 clientes

- **Objetivos** 
	1. Ganar posicionamiento SEO Orgánico (personalización de Metadatos, Open Graphics, Schema, contenidos largos con FAQ, etc)
	2. Convertir visitas digitales en visitas físicas o llamadas telefónicas

- **Estrategia** principal es incidir en la reputación de Fausto y diferenciarse de las grandes Franquicias por atención, reputación, y Seguimiento de las necesidades del cliente.
- **Tono:** cálido, cercano y profesional. Como hablar con un especialista de confianza, no con una corporación.
- **Diferenciación clave:** 44 años de historia local, caras conocidas (continuidad familiar o de equipo, frente a la rotación de personal de las franquicias). Conocimiento del cliente y Seguimiento de sus necesidades.
- **Promesa de valor:** «Nos conocemos de toda la vida. Y eso se nota.» Seguimiento del cliente.
- **Target**: 
| Perfil | Características clave |
|---|---|
| Residente local (45–75 años) | Conoce la marca, busca refuerzo de confianza y comodidad digital |
| Turista extranjero (65+ años) | Principalmente anglófono; puede necesitar atención urgente de visión o audición durante su estancia |
| Persona mayor (75+) | Poca familiaridad tecnológica; necesita claridad absoluta, texto grande y CTA directa |

## // NOTAS:
- usar como base pero modificar añadiendo o suprimiendo según conveniencia (orden, estructura, seo, estrategia  y toque emocional)
- usar misma estructura CTA (llamada y whatsapp directo)
- se usa el page ID en formato "X.X.X -" que no es parte del título sino un indicador interno para Claude y para mi.
- lás páginas 2.1.x 2.2.x 3.1.x y 3.2.x deben tener Breadcums y añadirlo en el schema de sus padres.

<HR>
================================
# ESTRUCTURA WEB
=========
0.0 Inicio
1.0 Nosotros
2.0 Visión (landing) 
	-- (section, NO page) Visión  / Servicios /
		--- 2.1.1 Optometría
        --- 2.1.2 Visión Infantil
        --- 2.1.3 Control de Miopía
        --- 2.1.4 Baja Visión
        --- 2.1.5 Visión +40
        --- 2.1.6 Terapia Visual
	-- (section, NO page) Visión / Productos / 
		--- 2.2.1 Lentes Oftálmicas
		--- 2.2.2 Gafas Progresivas
		--- 2.2.3 Lentes de Contacto
		--- 2.2.4 Filtros solares y luz azul
		--- 2.2.5 Ayudas Visuales
		--- 2.2.6 Gafas Infantiles
		--- 2.2.7 Gafas Deportivas
3.0 Audición (landing)
	-- (section, NO page) Audición / Servicios  /
            --- 3.1.1 Audiometría
			--- 3.1.2 Adaptación de audífonos en adultos y niños
            --- 3.1.3 Tinnitus
            --- 3.1.4 Mantenimiento de audífonos
            --- 3.1.5 Rehabilitación auditiva 
	-- (section, NO page) Audición / Productos / 
            --- 3.2.1 Audífonos
            --- 3.2.2 Ayudas Auditivas
            --- 3.2.3 Protectores a medida

4.0 Contacto
-
o1 404 personalizada
o2 Asiso Legal
o3 Política de privacidad


## Convenciones

Los identificadores 2.1, 2.2, 3.1 y 3.2 son exclusivamente editoriales.

Las carpetas `servicios` y `productos` existen únicamente para organizar el contenido y enriquecer los slugs.

No representan páginas, no aparecen en la navegación y no generan breadcrumbs.

NOTA: 2.1 , 2.2, 3.1 y 3.2 no son páginas sino carpetas que contienen a las del sub-nivel. 
Las 2.1.x , 2.2.x, 3.1.x y 3.2.x reciben los enlaces desde 2.0 y 3.0, donde aparecen listadas como cards / blog posts lists de Servicios o de Productos.

## Slugs
/
/nosotros/
/vision/
/vision/servicios/optometria/
/vision/servicios/vision-infantil/
/vision/servicios/control-miopia/
/vision/servicios/baja-vision/
/vision/servicios/vision-40/
/vision/servicios/terapia-visual/
/vision/productos/lentes-oftalmicas/
/vision/productos/gafas-progresivas/
/vision/productos/lentes-de-contacto/
/vision/productos/filtros/
/vision/productos/ayudas-visuales/
/vision/productos/gafas-infantiles/
/vision/productos/gafas-deportivas/
/audicion/
/audicion/servicios/audiometria/
/audicion/servicios/adaptacion-audifonos/
/audicion/servicios/tinnitus/
/audicion/servicios/rehabilitacion-auditiva/
/audicion/servicios/mantenimiento-audifonos/
/audicion/productos/audifonos/
/audicion/productos/ayudas-auditivas/
/audicion/productos/protectores-a-medida/
/contacto/
/aviso-legal/
/politica-privacidad/
/404/

## parciales comunes

c01- header
	logo + navegador (o hamburguer)
c02- footer
    c02.1
    logo + Evaluamos y cuidamos tu salud ocular y auditiva.
    c02.2
    Centro Óptico Auditivo Fausto I
    Avd. Andalucía, 84 B Torre del Mar - Málaga
    // Usar iconos svg, en lugar de "Teléfono" "Email" y "Ubicación"
    Teléfono: (+34) 952 54 09 64
    Email info@opticafausto.com
    c02.3
    Centro Óptico Auditivo Fausto II
    C/ Duque De Ahumada, 1C Torre del Mar – Málaga
    Teléfono (+34) 952 54 70 90
    
_______ <hr>
================================
# CONTENIDOS:
============

# 0.0 - INICIO

## HERO

**Titular:** 44 años cuidando la vista y el oído de Torre del Mar

**Subtítulo:** Desde 1982, una óptica y centro auditivo familiar donde el equipo que te atiende es el mismo que te atendió la última vez. Y la anterior.

HEMOS AYUDADO A VER Y OIR MEJOR A MÁS DE 27.000 PERSONAS

*(Foto real del equipo en una de las tiendas, no stock)*

Pide tu cita [Llamada] [Whatsapp]

## MENSAJE POR AUDIENCIA
*(slider o banner rotativo, ver ap4.1 del proyecto — 3 variantes, 5-6 seg cada una)*

1. «Nos conocemos de toda la vida. Y eso se nota.»
2. «Aquí no eres un número de cita. Eres Carmen, Pepe, María… y lo sabemos.»
3. «¿Problemas de vista o de oído durante tus vacaciones? Atención rápida, sin cita previa.»

## WHY US — Atención humana, no de franquicia

Banner CTA destacado:

> «Si entras en Fausto, lo más probable es que Anabel o Leito ya sepan que llevas progresivos desde hace tres años.»

**En una franquicia** entras, coges turno y te atiende quien esté libre. Puede ser la misma persona que la última vez, o puede no serlo — y si no lo es, vuelves a contar tu historia desde cero: qué gafas llevas, qué te molestaba, qué probaste y no funcionó. El protocolo es el mismo en cualquier ciudad de España, lo decida quien lo decida desde una oficina central.

**En Fausto** entras, y antes de que digas nada, alguien te llama por tu nombre. Sabe que llevas progresivos desde hace tres años, que el año pasado te costó adaptarte a la montura nueva, y que la próxima revisión te toca en primavera. Porque no es un protocolo: es Anabel, es Leito, es la misma familia equipo que lleva años aquí, en Torre del Mar — y seguirá estando cuando vuelvas.

Esa es la diferencia que no se puede fingir en un anuncio: **atención humana, de quien quiere conocerte y te seguirá atendiendo durante años.**

- Mismo equipo, año tras año — sin rotación de personal
- Seguimiento real después de la compra, no solo durante la venta
- Decisiones que se toman en la tienda, no en un protocolo nacional
- 44 años de experiencia local en Torre del Mar, desde 1982

## NOSOTROS ÓPTICAS FAUSTO

Desde 1982 cuidamos la vista y el oído de Torre del Mar. Dos centros, un mismo compromiso: conocer a cada cliente y acompañarle, no solo venderle. Por eso, generación tras generación, muchas familias del pueblo siguen confiando en nosotros para algo tan importante como ver y oír bien.

[Conócenos →]

## TESTIMONIOS

> «Llevo viniendo desde hace más de 15 años. Cada vez que entro me preguntan cómo me va con las gafas, no solo si quiero comprar otras.» — *Cliente de Torre del Mar*

> «Mi madre tiene 82 años y aquí la tratan con una paciencia que no encontramos en ningún otro sitio.» — *Familiar de cliente*

> «Vine de vacaciones con un problema en el audífono y me lo resolvieron el mismo día, sin cita previa.» — *Cliente visitante*

*(Sustituir por testimonios reales una vez recogidos; mantener formato breve, una idea por cita)*

## ELECCIÓN DE INTERÉS

**Visión** — <<Recupera la alegría de los detalles>>
[Ver Visión →]

**Audición** — <<Vuelve a oír bien y conectar>>
[Ver Audición →]

## CTA VISIÓN

¿Hace tiempo que no te revisas la vista? Una revisión completa puede ser la diferencia entre seguir forzando la vista o volver a ver con nitidez.
Pide tu revisión visual [Llamada] [Whatsapp]

## CTA AUDICIÓN

Somos Centro Auditivo Homologado y disponemos del equipo humano y tecnología necesaria para evaluar tu pérdida auditiva y recomendarte la solución que mejor se adapte a tus necesidades.
Solicita tu estudio auditivo [Llamada] [Whatsapp]

## FRANJA DE CONFIANZA

44 años de experiencia · Empresa familiar desde 1982 · 2 locales en Torre del Mar · xxx Miles de clientes atendidos · Centro Auditivo Homologado · Atención en inglés y alemán

## FAQ — Preguntas frecuentes

**¿Necesito cita previa?**
No es imprescindible, aunque recomendamos pedirla para evitar esperas, especialmente en temporada alta.

**¿Cuánto tarda una revisión visual?**
Una revisión completa suele durar entre 20 y 30 minutos, dependiendo de las pruebas necesarias.

**¿Pueden reparar mis gafas en el día?**
En la mayoría de los casos sí. Tráelas y te decimos al momento si es posible.

**¿Cuánto dura la prueba de audífono?**
La primera valoración auditiva dura unos 30-40 minutos. La prueba del audífono se hace sin compromiso y puedes llevártelo a casa antes de decidir.

**¿Atienden en otros idiomas?**
Sí, hablamos inglés y alemán. 
____________ <hr>

# 1.0 - NOSOTROS - Ópticas Fausto –

## HERO

Más de 44 años mirando por ti.
A tu servicio desde 1982.

Desde el principio, nuestra filosofía ha sido ofrecer un trato cercano y profesional a cada cliente, con un equipo humano cualificado y la última tecnología en cuidado visual y auditivo.

*(imágenes de las fachadas e instalaciones — posible galería)*

## NUESTRA HISTORIA

En 1982 abrimos las puertas del primer Centro Óptico Auditivo Fausto en Torre del Mar. Desde entonces, tres generaciones han pasado por nuestras tiendas para cuidar su vista y su oído — y muchas de esas mismas familias siguen viniendo hoy.

No somos una franquicia que llegó al pueblo hace dos años. Somos parte de Torre del Mar desde hace ya 44, y eso se nota en cada visita: en que recordamos tu graduación sin mirar la ficha, en que sabemos qué montura te gustó la última vez, en que cuando vuelves no empiezas de cero.

## POR QUÉ SOMOS DIFERENTES A UNA FRANQUICIA

Las grandes franquicias ópticas tienen locales más grandes y más publicidad. Lo que no tienen es continuidad: el personal rota, los protocolos vienen dictados desde fuera y cada visita puede tocarte una persona distinta que no te conoce de nada.

En Fausto pasa lo contrario:

- **Mismo equipo, año tras año.** Las personas que te atienden hoy son las mismas que te atendieron la última vez — y probablemente te atiendan dentro de cinco años.
- **Seguimiento real.** No desaparecemos después de la venta. Si algo no te funciona, vuelves y lo resolvemos, sin que tengas que volver a explicar tu caso desde el principio.
- **Decisiones tomadas aquí, no en una central.** Cuando hace falta encontrar una solución poco habitual, decidimos nosotros, en la tienda, pensando en ti — no seguimos un guion.
- **Sin presión de ventas.** Te asesoramos con honestidad, aunque eso signifique recomendarte la opción más sencilla en lugar de la más cara.

En Centros Óptico Auditivo Fausto encontrarás el mejor asesoramiento para el cuidado de tu visión y tu audición, con la cercanía que solo da conocerse de toda la vida.

## EL EQUIPO

*(fotos reales del equipo, nombres y especialidades — sustituir placeholder al recibir el material)*

Nuestra experiencia nos permite ofrecerte las mejores opciones en gafas, soluciones visuales, lentes oftálmicas, lentes de contacto y audífonos. Trabajamos en dos líneas que son la base de todo lo que hacemos:

**Atención humana**, de quien quiere conocerte y seguirá atendiéndote durante años. Cada persona recibe un trato individualizado en función de sus necesidades reales, no de un protocolo estándar.

**Formación continuada**, para poder dar respuesta a los problemas visuales y auditivos más actuales con las técnicas y tecnologías más recientes.

- Optometría y productos de optometría
- Audiometría y productos de audiometría

## LOS DOS LOCALES

**Centro Fausto Avenida** — Av. Andalucía, 84 B, Torre del Mar
**Centro Fausto Duque** — C/ Duque de Ahumada, 1C, Torre del Mar

Horario en ambos: 10:00–13:30 y 17:00–20:30.

[Ver ubicación en el mapa] Pide tu cita [Llamada] [Whatsapp] 

## TESTIMONIOS

> «Después de tantos años, ya ni me preguntan qué uso. Lo saben.» — *Cliente de Torre del Mar*

> «Se nota que les importa de verdad, no solo vender.» — *Cliente habitual*

*(Sustituir por testimonios reales una vez recogidos)*

_______ <HR>
# 2.0 - VISIÓN

## HERO

Hay días en los que el mundo se ve un poco menos nítido y nos acostumbramos sin darnos cuenta. El color de una puesta de sol, la letra pequeña de un libro, la cara de alguien al otro lado de la calle: pequeños detalles que dejamos de ver sin notar cuándo empezó.

Reconocer a tiempo un problema de visión no es un signo de debilidad, es el primer paso para recuperar algo que muchas veces dábamos por perdido sin razón. En Ópticas Fausto llevamos 44 años, desde 1982, ayudando a la gente de Torre del Mar a volver a ver con claridad — sin prisas, sin presión, con la confianza de quien te conoce.

[Pide tu revisión visual] [Llamada] [Whatsapp] 

## SERVICIOS DE VISIÓN

**Déjanos ver cómo nos ves.**

Un examen visual completo es mucho más que "leer letras de una pared". Es el primer paso para detectar a tiempo cualquier problema, antes de que se convierta en algo que afecte a tu día a día: dolores de cabeza, fatiga al leer, dificultad para concentrarte o, simplemente, dejar de ver mal sin saber por qué.

*(lista de cards con elementos 2.1.x — imagen, título, descripción breve, [Ver más])*

## PRODUCTOS DE VISIÓN

Te asesoramos sobre los productos más adecuados para tu problema de visión. En nuestros centros óptico-auditivos Fausto de Torre del Mar contamos con personal cualificado para encontrar la solución que mejor se adapte a ti, sin presión y con seguimiento real después de la compra.

*(lista de cards con elementos 2.2.x — imagen, título, descripción breve, [Ver más])*

[Pide tu cita] [Llamar] [WhatsApp]

---
# 2.1.1 - OPTOMETRÍA TORRE DEL MAR

El sistema visual está integrado por los ojos, las vías visuales y el sistema nervioso central. Todas y cada una de estas estructuras deben estar en unas condiciones óptimas para su funcionamiento, permitiendo tener una visión eficaz

La evaluación completa del sistema visual incluye:

– Agudeza Visual
– Examen Refractivo (detectar posible miopía, hipermetropía o astigmatismo)
- Examen Binocular (oculomotricidad, acomodación, Vergencias, coordinación binocular, estereopsis),
- Examen de la Percepción Visual
- Examen de Salud Ocular.

Una optometría, o evaluación optométrica, completa es imprescindible para detectar cualquier desequilibrio o problema visual y poder actuar y plantear el tratamiento más adecuado que restablezca el equilibrio en la visión, ya sea una prescripción óptica en gafas o lentes de contacto, prismática y/o programa de terapia visual o bien, derivar al oftalmólogo ante la sospecha de posibles estados patológicos que puedan afectar a su sistema visual.

Revisiones periódicas de la visión nos permitirán actuar a tiempo y prevenir alteraciones en el sistema visual, el cual va a evolucionar a lo largo de nuestra vida y se ve afectado, entre otros factores, por nuestros hábitos diarios. 

[] Pide tu cita [Llamada] [Whatsapp] 

## Síntomas que esconden una alteración en el sistema visual

- Dolor de cabeza
- Sensación de tensión alrededor de los ojos
- Visión doble o Visión borrosa
- Lagrimeo o enrojecimiento ocular
- Picor de ojos cuando realiza tareas de cerca
- Frotarse los ojos a menudo
- Parpadear frecuentemente
- Fruncir el ceño para ver mejor
- Molestias o sensibilidad a la luz o halos alrededor de las luces
- Cansancio en la lectura
- Sensación de movimiento de las letras
- Falta de concentración en la lectura
- Sueño al leer….

_______ <hr>
# 2.1.2 - Visión Infantil

## HERO
// La importancia de actuar a tiempo

Hoy en día es más que evidente la importancia de evitar los problemas visuales de los niños en sus primeros años de vida.
Las anomalías visuales causan al menos una tercera parte del fracaso escolar.

Los más característicos a estas edades son:

- Hipermetropía (error refractivo en el cual la imagen de un objeto situado en el infinito se forma detrás de la retina. Suelen quejarse de dolores de cabeza al realizar trabajos en cerca, se acercan mucho al texto, o simplemente no prestan atención a la tarea)

- Miopía (error refractivo en el cual la imagen de un objeto situado en el infinito se forma delante de retina. No ven bien de lejos y si de cerca. Hay que prestar atención al comportamiento del niño ya que ellos no saben que ven mal, para ellos todo el mundo ve así. Si guiñan para ver de lejos o se acercan mucho al televisor hay que traerlos a hacer una revisión)

- Astigmatismo: error refractivo causado por una curvatura irregular de la córnea que da lugar a visión borrosa.

- Ambliopía: la pérdida de la capacidad de un ojo para ver los detalles, conocido como ojo vago. Es la causa más común de problemas de visión en niños.

- Estrabismo: la desviación de uno de los dos ojos que se aprecia a simple vista. En muchos casos está relacionado con la hipermetropía.

## LA IMPORTANCIA DE LA PREVENCIÓN EN NIÑOS

Recuerde que la prevención es importante para evitar un retraso en el desarrollo visual del niño, que afectará a su actividad escolar. Para ello recomendamos que controle su visión a partir de los 3 años y hacer controles anuales.

[cta] Es recomendable revisar a los niños cuanto antes. Consulte con su Óptico Optometristas. /  [Pide tu cita] [Llamada] [Whatsapp] 


## CONSEJOS DE HIGIENE VISUAL

- Hay que sentarse correctamente: pies apoyados en el suelo y espalda recta. Evitar leer tumbado, en el suelo o en la cama.
- Los muebles deben ser apropiados: la silla debe ser regulable en altura y la mesa de trabajo debe estar en un plano inclinado de unos 15º a 20 º, esto se puede conseguir también con un atril.
- La iluminación es muy importante: hay que estudiar con una iluminación en el techo y otra directamente en el plano de trabajo, que no dé directamente en los ojos, que no deslumbre y que no haga sombra al escribir. Colocar el flexo a la izquierda si la persona es diestra y viceversa y por encima del hombro si es posible.
- La distancia de lectura, no tiene que ser demasiado corta. La distancia ideal es aproximadamente del codo hasta el nudillo del dedo índice. Los antebrazos han de estar apoyados sobre el plano de trabajo.
- Al realizar las tareas de cerca, intentar ser consciente de lo que te rodea.
- No se debe leer moviendo la cabeza, sino con los ojos. Esto puede ser un signo de un problema visual.
- Situar la mesa de trabajo, a ser posible, delante de una ventana. Interrumpir la actividad visual prolongada en visión próxima, levantando la cabeza y mirando a lo lejos: cada 20 minutos descansa 20 segundos , parpadea 20 veces y mira a 20 pies (6 metros)
- En cuanto a la televisión: evitar brillos, nunca se debe ver con la luz apagada de la habitación y a una distancia mínima de 2 metros. Limitar el tiempo de ver TV a no más de 2 horas.
- Cuando vaya en coche, autobús o tren, evitar cualquier tarea de cerca.
- La dieta alimenticia debe ser rica en vitaminas: verduras y frutas.
- Son recomendables las salidas al campo, a espacios libres o abiertos. Es bueno realizar juegos y deportes al aire libre.

_______ <hr>
# 2.1.3 - Control de Miopía

La miopía en Europa se ha convertido, de unos años a esta parte, en un problema serio que afecta cada día a más personas. Frenar el avance de la miopía, especialmente entre la población más joven, es posible gracias a la Ortoqueratología.

La ortoqueratología se basa en utilizar unas lentes durante la noche que modifican la curvatura de la córnea, eliminando así la miopía a tratar, haciendo que el paciente vea perfectamente durante el día sin gafas ni lentes de contacto.

Recomendada en:

- Niños y adolescentes, entre los que la miopía suele avanzar de forma rápida, es una técnica muy recomendable.
- En personas que opositen y necesitan una buena visión sin gafas.
- Usuarios que practiquen deporte y usuarios que no desean llevar gafas.

    “Se trata de una técnica muy segura, pero requiere conocimientos especializados y tener un topógrafo corneal”, un instrumento indispensable para tratar de manera correcta e individualizada a los pacientes. 

-  [Pide tu cita] [Llamada] [Whatsapp] 

En la actualidad, la investigación sobre el control de la miopía se centra, además de en la orto-k con lentes permeables, en el uso de novedosos diseños de Lentes de Contacto blandas.
Ambos tratamientos están basados en el mecanismo de desenfoque de las imágenes en retina central y periférica, ya que este mecanismo, parece ser el principal responsable en el crecimiento de la longitud ocular y por ende, de la miopía.

Es una alternativa para aquellos pacientes que por sus condiciones oculares no puedan o no quieras optar por la cirugía refractiva.

_______ <hr>
# 2.1.4 - Baja Visión

La baja visión es una pérdida de agudeza visual que no puede ser corregida con gafas convencionales, lentes de contacto, tratamientos farmacológicos o cirugía, y que dificulta la realización de ciertas actividades como la lectura, la escritura, ver la televisión, conducir o reconocer caras.

 Esta limitación puede estar causada por distintas patologías, como pueden ser:

- Degeneración macular
- Retinopatía diabética
- Retinosis pigmentaria
- Glaucoma
- Albinismo

### ¿Qué enfermedades producen baja visión? 
Aquellas relacionadas con el envejecimiento, traumatismos, patologías congénitas y genéticas.

Las más comunes son:
- Degeneración macular asociada a la edad (DMAE): Enfermedad degenerativa que afecta a la zona central de la retina. Con afectación del campo visual central.
- Glaucoma: Enfermedad crónica y progresiva. Con pérdida de campo visual periférico.
- Miopía Degenerativa: Cuando tiene más de 6 dioptrías, suele ser hereditaria. Con mayor riesgo de enfermedades de la retina.
- Retinopatías diabéticas e hipertensivas: Es una complicación por la diabetes. Con visión borrosa, sombras o áreas de pérdidas de visión, dificultad para ver por la noche.
- Retinosis pigmentaria: Enfermedad genética con pérdida de campo visual periférico y problemas nocturnos.

### ¿Cuáles pueden ser los síntomas de baja visión?

- Visión borrosa, sin problemas de campo visual.
- Pérdida central o parcial del campo visual.
- Distorsión de la imagen.
- Distorsión de los colores.

### ¿Qué tipo de ayudas hay para baja visión?

- Ópticas: Lupas, microscopios, telescopios, telemicroscopios y gafas prismáticas.
- No ópticas (mejoran la ergonomía): Filtros selectivos, atriles y mejoras en la iluminación.
- Electrónicas (amplían por proyección): Circuitos cerrados de televisión.

La finalidad de las ayudas de baja visión es potenciar su resto visual, que permitirá recuperar actividades abandonadas y mantener una cierta independencia.

_______ <hr>
# 2.1.5 - Visión +40

## HERO **No te quedes detrás: que tu vista siga siendo de lince.**
// *(imagen: persona andaluza de unos 40-45 años, frotándose los ojos delante de un portátil — esa escena de "no veo bien, pero todavía no quiero admitirlo")*

A los 40 y algo empieza a cambiar y casi nadie quiere reconocerlo: el WhatsApp se aleja un poco más del brazo, la carta del restaurante de repente está mal iluminada, las letras pequeñas del periódico se "amontonan". No es que tus ojos fallen — es la vista cansada, y le pasa prácticamente a todo el mundo a partir de esta edad. La buena noticia es que tiene solución, y cuanto antes la abordes, menos te costará adaptarte.

Pide tu cita [Llamada] [Whatsapp] 

## CAMBIOS EN TU VISIÓN PASADOS LOS 40 AÑOS

Al igual que pasa el tiempo, tu cuerpo cambia. El color del pelo, la textura de la piel, el tono de voz. Inevitablemente, tu visión también cambia.

Sin embargo, los cambios en tu visión no tienen por qué cambiarte la vida. Un programa de prevención mediante exámenes visuales y un tratamiento puntual y rápido de los problemas puede mantener tus ojos en el mejor estado durante toda la vida.

El defecto refractivo que más afecta a nuestro día a día a partir de esta edad es la **presbicia**, o vista cansada.

Comienza a evolucionar a partir de los cuarenta años, y cerca del cien por cien de las personas mayores de cincuenta la tienen.

¿Qué es la vista cansada o presbicia?
Es un defecto de la visión, por el que el ojo pierde la capacidad para enfocar los objetos cercanos.
En la presbicia, la capacidad de enfoque del ojo disminuye, lo que dificulta tareas en visión próxima como leer, escribir o coser. «Parece que tenemos los brazos demasiado cortos» — o notamos fatiga visual al leer, problemas para distinguir letra pequeña, o que las letras «se amontonan».

Pide tu cita [Llamada] [Whatsapp] 

## SOLUCIONES PARA PROBLEMAS DE VISIÓN PASADOS LOS 40 AÑOS

1. **Lentes progresivas** en gafas: un gran adelanto de la tecnología óptica. Cada día son más cómodas, con campos de visión laterales más amplios y adaptación garantizada.
2. **Lentes de contacto progresivas**, con las que tendrás total libertad a todas las distancias.
3. **Lentes ocupacionales**, para quienes pasan largos periodos trabajando con el ordenador.

Otros problemas que pueden aparecer con la edad y afectar a tu visión son el glaucoma, la retinopatía diabética, la degeneración macular asociada a la edad y las cataratas. Una revisión periódica permite detectarlos a tiempo.

_______ <hr>

# 2.1.6 - Terapia Visual

## HERO - El gimnasio de tus ojos

Aunque la mayoría de los problemas visuales se pueden corregir mediante el uso de gafas o lentes de contacto, algunos problemas requieren de Terapia Visual.

La visión no es tan solo tener una buena agudeza visual, sino que comprende numerosas habilidades que con terapia visual podemos mejorar: Movimientos oculares de fijación y seguimientos, cambio de enfoque, binocularidad (habilidad de usar ambos ojos a la vez), mantener la atención, estrés visual por excesivo trabajo en cerca, o incluso mejorar deficiencias visuo-motoras o perceptivas-cognitivas fundamentales en la escuela.

La Terapia Visual es un programa de tratamiento individualizado que se prescribe para mejorar y/o desarrollar las habilidades visuales o compensar los problemas visuales.

Se compone de una serie de procedimientos, que se realizan en consulta y en casa, bajo la supervisión de nuestros ópticos - optometristas.

Pide tu cita [Llamada] [Whatsapp] 

## EL PESO DE NO DIAGNOSTICAR A TIEMPO

La mayor parte de las dificultades en el aprendizaje de la lectura y la escritura se deben a un pobre desarrollo de las habilidades visuales.

## SIGNOS Y SÍNTOMAS QUE PUEDEN INDICAR LA NECESIDAD DE TERAPIA VISUAL TANTO EN NIÑOS COMO EN ADULTOS:
- Colocar el material de trabajo demasiado cerca.
- Inclinar la cabeza al leer, o movimiento de la misma para seguir la lectura.
- Corta duración de la atención y/o cansancio cuando se realizan tareas que requieren concentración.
- Guiñar o tapar uno de los ojos cuando lee o escribe.
- Ocasionalmente o continuamente afirma ver borroso o doble cuando lee o escribe.
- Picor, cansancio o enrojecimiento de los ojos tras realizar tareas de cerca.
- Experimentar dolor de cabeza o incomodidad después de haber realizado una tarea en cerca.
- Si es estudiante, problemas al copiar de la pizarra, o al cambiar la visión de la pizarra al papel o viceversa.
- Ambliopía (ojo vago).

No todos los problemas de aprendizaje guardan relación con disfunciones visuales, pero sí es primordial un examen visual completo para descartar la parte visual.

_______ <hr>
# 2.2.1 - Lentes Oftálmicas

## HERO - 

## ¿Qué son las lentes Oftálmicas?

Son lentes oftálmicas las lentes que montamos en las gafas y que están destinadas a compensar los defectos visuales (Astigmatismo, Hipermetropía y Miopía, presbicia o vista cansada)

### Tipos de lentes oftálmicas

- Monofocales: Tienen una sola graduación para lejos o cerca.
- Bifocales: Tienen dos graduaciones, la parte superior se utiliza para la visión de lejos y la parte inferior se utiliza para la visión de cerca.
- Progresivas: Permiten visión a todas las distancias: cerca, lejos y visión intermedia. Con las nuevas tecnologías y su personalización la adaptación está garantizada.

### ¿De qué materiales se fabrican?

Son tres los más utilizados:
- Orgánico: Material similar al plástico, de alta tecnología. Lentes de poco peso y muy resistentes a los golpes. Es el más utilizado.
- Mineral: Se le llama también vidrio, son lentes más pesadas que las orgánicas, pero se rompen con facilidad al golpearse.

### ¿Qué tratamientos podemos aplicar para mejorarlas?

- Endurecido: Tratamiento aplicado a las lentes oftálmicas orgánicas para hacerlas más resistentes al rayado.
- Antirreflejante: Tratamiento que disminuye la reflexión de la luz hasta en un 98%, con este tratamiento la lente obtiene una mayor transparencia, consiguiendo el usuario una mejor calidad visual y confort.
- Fotocromático: Con este tratamiento conseguimos que las lentes cambien de color en función de la luz solar que reciben. Oscurece en el exterior y permanecen transparentes en el interior.

### Personalización de tus lentes 
Hoy en día debido a la calidad de la maquinaria utilizada para la fabricación de las lentes oftálmicas podemos personalizar cualquiera de ellas ya sean monofocales o progresivas, ampliando así los campos de visión, reduciendo las aberraciones  y maximizando el confort en el porte de las mismas.

Pide tu cita [Llamada] [Whatsapp] 


### Cuidado y limpieza de las lentes oftálmicas

- Limpiarlas siempre en húmedo, con agua y jabón neutro o cualquier líquido de limpieza recomendado por su óptico. Secarlas con la gamuza, nunca con papel, con pañuelos ni con nuestra propia ropa. No se aconseja limpiarlas con productos que contengan desengrasante y detergente.
- No utilizar productos corrosivos que puedan dañar las lentes como laca, disolvente, etc.
- Quitarse las gafas con las dos manos para evitar malformaciones.
- No apoyar las gafas por el lado de las lentes para evitar rayados.
- No acercar las gafas a fuentes de calor como estufas, ni tampoco dejarlas en guanteras de coches (pueden alcanzar temperaturas muy altas), el calor podría deformarlas.

_______ <hr>
# 2.2.2 Gafas Progresivas

## HERO - El todoterreno para tu visión

Oferta 2×1 LENTES PROGRESIVAS

// desarrolla CALIDADES DEL CRISTAL. GAMAS y diferencia en resultados. Garantías y CERTIFICADOS del fabricante

## ¿QUE ES UNA LENTE PROGRESIVA?
Es una lente oftálmica con un diseño complejo capaz de permitir al usuario ver a todas las distancias: lejana, intermedia y cercana

## Preguntas Frecuentes

### ¿A QUIÉN SE LE RECOMIENDAN LENTES PROGRESIVAS?
- Personas a partir de 40-45 años con dificultades para leer de cerca
- con trabajos a distintas distancias: ordenador, deporte, conducción
- para personas activas que quieren usar una sola gafa para todas las actividades y quieren enfocar  distintos objetos situados a diferentes distancias.
- operados de cataratas

### ¿ES COMPLICADA LA ADAPTACIÓN DE UNA LENTE PROGRESIVA?
Hoy en día con la tecnología existente permite una visión natural para cualquier demanda visual requerida.

### ¿NECESITA ADAPTACIÓN EL USAR UNA GAFA PROGRESIVA?
Como cualquier gafa tenemos un periodo de adaptación , aunque en la actualidad este periodo es muy corto.

### ¿CÓMO ELEGIR EL MEJOR PROGRESIVO PARA MI?
Seguir las indicaciones de tu óptico-optometrista, quien te aconsejará cual es el más indicado para tu visión, necesidades visuales y ritmo de vida

### ¿PODEMOS TENER UNAS GAFAS DE SOL PROGRESIVAS?
Es recomendable la utilización de gafas de sol y al usar progresivas tiene un valor añadido: podemos leer con ellas sin necesidad de cambiar de gafas.  Su óptico –optometristas le recomendará el mejor filtro para sus ojos pudiendo ser un filtro selectivo, polarizado o incluso fotocromático (cambian con el sol)

### ¿QUÉ SON LOS PROGRESIVOS OCUPACIONALES?
Son gafas que están más indicadas para el trabajo de cerca, ordenador y para distancia de 4 metros, permite al usuario moverse por el lugar de trabajo y con la ventaja de tener un campo muy amplio de distancia intermedia, lo que hace ser súper cómodas para las personas que trabajan con ordenador

### ¿NECESITAMOS PONER FILTRO PARA EL ORDENADOR?
Hoy en día pasamos la mayor parte de nuestro tiempo frente a l ordenador y a los dispositivos electrónicos : móvil , tablet, etc.

Es conveniente la utilización de filtros especiales para la luz azul, ya que el abuso de esta  luz conlleva molestias oculares e incluso afecta a nuestro ciclo circadiano (dia y noche)y descansamos peor.

// incorporo LANDING GAFAS GRADUADAS
[https://lentes-graduadas.opticafausto.com/]{GAFAS GRADUADAS}

_______ <hr>
# 2.2.3 - Lentillas - Lentes de Contacto

## HERO - Lentillas: el superpoder oculto
## ¿Por qué usar lentillas?

Millones de personas ven muy bien, y nadie sabe que es gracias a que llevan lentes de contacto 
Casi cualquier persona puede usar lentes de contacto 
Las lentes de contacto o lentillas permiten ver bien y liberarnos del uso de gafas

## Beneficios de las lentes de contacto
Anti vaho
    Actualmente con el uso de mascarilla nos evita el efecto vaho en las gafas
Confort
    Son cómodas, fáciles de usar y con los materiales actuales podemos usarlas durante un gran número de hora al día
Visión periférica
    Permiten un mayor campo de visión, mejorando la visión periférica, siendo muy ventajoso para la práctica de deportes
Gafas de sol
    Puedes usar cualquier gafa de sol de moda ya que tu graduación está en las lentillas

Las lentillas te proporcionan una visión completa, clara y con libertad de movimiento, por eso te damos 10 razones por las que las lentillas le darán un cambio a tu visión, comodidad y aspecto.

1. Las lentillas se mueven con tus ojos para proporcionarte un campo de visión completo, lo que te ayuda a seguir cualquier acción con una visión clara, nítida, directa y periférica.
2. Puedes ver con claridad, incluso con luz baja.
3. No recibes los reflejos y la distorsión que aparece con las gafas.
4. No se salpican, dándote una visión más clara, aunque llueva.
5. No se empañan cuando entras en un espacio más caliente.
6. Las lentillas son más ligeras y obstaculizan menos que las gafas.
7. No se te clavan sobre la nariz ni te rozan las orejas.
8. Puedes llevar gafas de sol y no interfieren con los cascos para deportes activos.
9. Las lentillas pueden mejorar la forma en que te ves y te sientes y cómo te ven los demás.
10. Te proporcionan un aspecto natural, sin marcos que obstruyan tu cara y no evitan que luzcas tus ojos maquillados.

[banner]¿Quieres experimentar la sensación de usar lentillas, sin sentir que las llevas puestas?

## NUESTRAS LENTILLAS
01. LENTILLAS MISIGHT
Actualmente existen lentillas para control de miopía en niños y jóvenes que han demostrado ralentizar significativamente la progresión de su miopía.

02. LENTILLAS MIOPÍA, HIPERMETROPÍA Y ASTIGMATISMO
Con opciones que se adaptan prácticamente a cualquier paciente y cualquier problema de visión, ideales para hacer deporte

03. LENTILLAS PRÉSBITAS
En la actualidad la lente de contacto multifocal es una buena forma de compensar la vista cansada o presbicia.


Centro Óptico Auditivo Fausto somos un centro con experiencia y trabajamos todo tipo de lentes de contacto, para encontrar la que realmente necesitas hacemos una adaptación personalizada con un estudio de la medida de la córnea, tanto de su curvatura como de su diámetro, realizamos un examen visual y exploración externa del ojo para valorar cualquier anomalía y evaluamos la calidad de la película lagrimal, tan importante para el porte de lentes de contacto y así determinar el tipo de lentes más adecuada, para cada paciente y estilo de vida.

## TIPOS DE LENTILLAS

Permeables RGP: indicadas para corregir cualquier defecto refractivo , presbicia, OrtoK consiguiendo una buena calidad visual.
Blandas para corregir miopía, hipermetropía, astigmatismo, vista cansada y con todas las variantes que se adapten mejor a cada caso de paciente y estilo de vida.
Pueden ser desechables, (diarias y mensuales)
Lentes cosméticas para cambiar el color de tus ojos.
Lentes terapéuticas para úlceras corneales, triquiasis, amaurosis, etc.…

### LENTES COSMÉTICAS DE COLOR
En Centro Óptico Auditivo Fausto adaptamos lentes de color, las cuales son una opción para aquellas personas que quieren probar un color de ojos diferente.

### LENTES DE CONTACTO PARA JÓVENES Y NIÑOS
En los niños y jóvenes el uso de lentes de contacto además de darles mayor campo de visión, les puede facilitar la práctica de deportes (muy importante para su desarrollo), y darle más seguridad a la hora de correr, saltar, y moverse.

### LENTES TERAPÉUTICAS
Adaptamos  lentes de contacto terapéuticas que  se utilizan como “vendaje ocular” para proteger la superficie del ojo dañado debido a una úlcera o distrofia, evitando el dolor y ayudando a la regeneración de la córnea.

### CÓRNEA IRREGULAR-QUERATOCONO
El queratocono es una alteración de la curvatura de la córnea, la cual se produce y como consecuencia se produce un astigmatismo que no es corregible con gafas y necesita un lente de contacto especial para mejorar la visión.
Ciertas alteraciones corneales destacando el queratocono provocan una mala calidad visual. Por ello, la adaptación de una Lente de Contacto especial es el mejor método para mejorar la visión de estos pacientes y con ello, su calidad de vida.
En Centro Óptico Auditivo Fausto adaptamos lentes de contacto para queratocono

### LENTES PARA PRESBICIA
En la actualidad la lente de contacto multifocal es una buena forma de compensar la vista cansada o presbicia.

### ORTOQUERATOLOGÍA (ORTO-K)
La Ortoqueratología es una técnica para la compensación de la miopía mediante lentes de contacto, por la noche mientras duermes. (Ver control de miopía)

La miopía en Europa se ha convertido en un problema serio que afecta cada día a más personas. Frenar el avance de la miopía, especialmente entre la población más joven, es posible gracias a la Ortoqueratología.
Orto-K (ortoqueratología), te permite ver durante todo el día sin gafas ni lentes de contacto 

Pide tu cita [Llamada] [Whatsapp] 

## FAQ - preguntas frecuentes

Si no estás familiarizado con las lentes de contacto te ofrecemos conocerlas y compartir contigo algunos consejos y dudas sobre las lentes de contacto

¿Es seguro usar lentes de contacto?

Las lentes de contacto son seguras siempre que la adaptación se haga por un profesional óptico optometrista y que cumplas todos sus consejos de manipulación, limpieza y horas de uso.

¿Es fácil la manipulación de las lentes de contacto? Ponerlas, quitarlas, sacarlas del blíster etc.

Las lentes de contacto están diseñadas para una fácil manipulación. Consulta con nuestros profesionales de la visión para aprender a manipular las lentes de contacto de manera segura e higiénica.

¿Cómo me pongo y me quito las lentes de contacto?

Nuestros ópticos optometristas y auxiliares te enseñarán como ponerte y quitarte las lentes de contacto. Mostrándote la manera más fácil.

¿Tengo que lavarme las manos antes de manipular las lentes de contacto?

Antes de que vayas a ponerte, quitarte o manipular las lentillas siempre debes lavarte las manos. Te daremos las recomendaciones necesarias para una correcta higiene.

¿Tengo que tener cuidado al usar lentes de contacto durante mis actividades diarias?

Las lentes de contacto te permitirán realizar la mayoría de tus actividades con una visión correcta, siempre debes seguir nuestras recomendaciones

¿Cuándo me las tengo que quitar?

Te explicaremos cuando debes quitártelas. Recuerda que si son diarias desecharlas al final del día y usar unas nuevas al siguiente día. Si son mensuales las quitarlas cada día y desecharlas al mes de abrir el envase.

¿Tengo que limpiar las lentes de contacto?

Las lentes mensuales debes de limpiarlas cada vez que te las quites con los líquidos que te recomendamos como óptico optometrista. Las lentes de contacto diarias están diseñadas para desecharlas todos los días, con lo que no es necesario limpiarlas. Son usadas y desechadas el mismo día.

¿Podría dormir con las lentes de contacto?

Las lentes de contacto deben ser retiradas cuando se va a dormir.

¿Qué ocurre si tengo alergia?

Esta situación la debes comentar con tu profesional de la visión. Las lentes de contacto diarias suelen ser una buena opción para pacientes con alergia ya que minimizan la contaminación de la lente y el riesgo de infección.

¿Puedo maquillarme si uso lentes de contacto?

No hay problema con el maquillaje, te indicaremos como hacerlo.

¿Cómo puedo saber si todo está correcto cuando uso lentes de contacto?

Una buena visión y una ausencia de signos externos como ojo rojo, excesivo lagrimeo, excesivo parpadeo o excesiva sensibilidad a la luz indican una correcta situación de la lente en el ojo. En cualquier caso, nuestros ópticos optometristas programará un plan de visitas para hacer un seguimiento del uso de las lentes de contacto.

¿Se pueden usar lentes de contacto al practicar deporte?

Es recomendable el uso de lentes de contacto para corregir la visión en personas que practican deporte, ya que frecuentemente evitarán problemas debido al uso de gafas en estas actividades.

¿Se pueden usar lentes de contacto mientras se nada?

Se pueden usar lentes de contacto mientras se nada con una protección adecuada de los ojos con unas gafas especiales de natación en cualquier caso se deben seguir las instrucciones de su profesional de la visión respecto a este tema.

¿Qué ocurre si noto que mis ojos están secos?

En este caso se debe contactar con su profesional de la visión para que le proporcione una solución más apropiada a este problema.

¿Cuándo se deben desechar las lentes de contacto?

Las lentes de contacto mensuales se deben desechar al mes de uso y las lentes diarias un solo uso, cada día y cada vez que se usen las lentes de contacto, están deberán de ser nuevas. Es la forma más higiénica de usarlas.

¿Qué ocurre si uso el mismo par de lentes más de un día?

Las lentes de contacto diarias están diseñadas para minimizar los riesgos de infección cambiándolas diariamente y desechándolas después de cada uso.

¿Continuaré usando gafas?

Si, las gafas las usarás siempre que no uses lentes de contacto. Sigue las recomendaciones de tu profesional de la visión.

¿Puedo usar gafas de sol con mis lentes de contacto?

No hay problema en usar gafas de sol y lentes de contacto a la vez. Pero siempre debes recordar que cuando uses lentes de contacto las gafas de sol no deben estar graduadas.
_______ <hr>

# 2.2.4 - Filtros solares y luz azul

## HERO - Protege tu vista de los daños

¿Sabías que el sol y las pantallas no afectan a tus ojos de la misma manera? Cada uno necesita su propia protección. En Ópticas Fausto evaluamos tu caso con nuestro equipo de exploración óptica para recomendarte qué filtro se adapta mejor a tu día a día, ya sea para conducir, estar al aire libre o pasar horas delante del ordenador o el móvil.

Pide tu cita [Llamada] [Whatsapp] 

## CÓMO TE ASESORAMOS
No recomendamos un filtro al azar: valoramos tu sensibilidad a la luz, tu actividad diaria y tu graduación actual con nuestro equipo de medición óptica, para que el tratamiento elegido encaje con tu visión real y no solo con una tendencia.

## FILTROS SOLARES
**Filtro Solar.** Tratamiento que se aplica a las lentes oftálmicas y reduce la cantidad de luz que llega al ojo, absorbiendo la radiación ultravioleta. Disponible en varios colores, siendo los principales el gris, el verde y el marrón — cada uno con un efecto distinto sobre el contraste y la percepción del color.

**Filtro Polarizado.** Tratamiento que elimina los reflejos y destellos de luz sobre superficies reflectantes (agua, cristal, asfalto mojado). Es especialmente útil para conducir, pescar, esquiar y practicar deportes al aire libre, donde el deslumbramiento puede llegar a ser peligroso.

## FILTROS PARA LUZ AZUL — LENTES CSR
Hoy pasamos buena parte del día frente a pantallas: ordenador, móvil, tablet, televisión. Esa exposición continuada a la luz azul puede traducirse en fatiga visual, molestias oculares e incluso afectar a la calidad del sueño, al interferir en el ciclo circadiano (día y noche).

Las lentes con tratamiento **CSR** tienen una función preventiva avalada por la UCM (Universidad Complutense de Madrid). Su uso continuado aporta, a corto plazo, más confort visual, mejor contraste y menos fatiga; a largo plazo, ayuda a prevenir el daño retiniano causado por la exposición prolongada a la luz.

Las principales fuentes de luz artificial que emiten luz azul son los ordenadores, televisores, tablets, luces LED y videoconsolas — es decir, prácticamente cualquier pantalla que usamos a diario.

**Recomendado para:** todos los usuarios y todas las edades, especialmente quienes trabajan muchas horas frente al ordenador o pasan tiempo prolongado con el móvil o la tablet.

## PREGUNTAS FRECUENTES
**¿Necesito graduación para llevar filtro de luz azul?**
No. El tratamiento CSR puede aplicarse tanto a lentes graduadas como a lentes neutras, sin graduación.

**¿El filtro solar cambia el color de mis lentes?**
Sí, los filtros solares tintan la lente según el color elegido (gris, verde o marrón), cada uno con matices distintos de contraste.

**¿Puedo combinar filtro solar y filtro de luz azul en la misma lente?**
Consúltanos tu caso: dependiendo del uso que le vayas a dar a la gafa, podemos recomendarte la combinación de tratamientos más adecuada.

[Pide tu cita] [Llamar] [WhatsApp]
_______ <hr>

# 2.2.5 - Ayudas Visuales y Filtros

##HERO - Una pequeña ayuda para lograr un gran cambio 

En Centros Óptico Auditivo Fausto contamos con especialistas en Baja Visión, pertenecientes a la Sociedad Española de la Baja Visión que darán soluciones, tratamiento y seguimiento a su problema visual.

[banner ] Ven y cuéntanos tu dificultad para que podamos encontrar la ayuda que te permita recuperar calidad de vida 
Pide tu cita [Llamada] [Whatsapp] 

## LUPAS
Son ayudas que permiten aumentar el tamaño de los objetos. Su amplio rango de aumentos las hace versátiles para múltiples usos.
- Lupas manuales
- Lupas soporte
- Lupas de pecho
- Lupas de bolsillo

Tanto con luz como sin luz.

## MICROSCOPIOS
Gafas convencionales, también llamadas “gafas lupas” con gran aumento permitiendo ver nítido cuando nos acercamos al objeto.

## TELESCOPIOS Y TELEMICROSCOPIOS
Ayuda para distancia lejana, intermedia o cerca. Son sistemas compuestos por varias lentes que proporcionan un amplio rango de aumentos. Y que permiten realizar una gran variedad de actividades como ver la televisión, trabajar con un ordenador o simplemente leer.

## LUPA TELEVISIÓN
Aumentan el tamaño de la imagen por medios electrónicos, permite leer a una distancia normal y el campo de lectura es mayor con el máximo aumento.
Permiten realizar gran variedad de tareas de forma prolongada. Pueden ser portátiles y fijas

## AYUDAS VISUALES NO ÓPTICAS

- Flexos de luz fría para una mejor iluminación y aumento del contraste.
- Atril para mejorar la posición de lectura.
- Teclado para ordenador con macrotipo y diferente fondo.
- Teléfonos con macrotipos.
- Reloj parlante.
- Enhebradores.

## FILTROS SELECTIVOS 

Son gafas con lentes terapéuticos que ofrecen un confort inmediato por la disminución del deslumbramiento, mejorando la percepción del contrate y ofreciendo una disminución del tiempo de adaptación a la luz.

Indicado para:
- Sensibilidad a la luz
- Problemas de deslumbramiento
- Agudeza visual reducida por pérdida de contraste
- Patologías como DMAE, cataratas…

## FILTRO ML DMAE Confort
Es una lente con filtro selectivo que bloquea la luz visible, más perjudicial y molesta, mientras deja pasar el resto de la luz visible.
Su exclusivo diseño permite aumentar el tamaño de la imagen retiniana para que el paciente pueda aprovechar al máximo las zonas de la retina que no han sufrido daño.
Las personas con Degeneración Macular DMAE podrán mejorar la calidad de vida y con mayor facilidad realizar tareas habituales como reconocer caras de las personas o distinguir bordillos . También aumentará su sensación de seguridad, dentro y fuera de la casa, al contribuir a disminuir los síntomas más limitantes de la patología.
Otras patologías como glaucoma o retinopatía diabética. Con similares síntomas pueden beneficiarse de la adaptación de ML DMAE Confort
_______ <hr>

# 2.2.6 - Gafas Infantiles

## HERO - Gafas chulas e irrompibles  // [subtítulo] Para que las usen y duren el mayor tiempo posible.
// ## incorporo LANDING VUELTALCOLE
[https://vueltaalcole.opticafausto.com/]{VUELTALCOLE}

El 80% de la información que llega a nuestro cerebro llega a través de los ojos.

Una dificultad visual puede provocar un problema de aprendizaje, por eso CENTRO OPTICO–AUDITIVO FAUSTO te recomienda una revisión visual completa .
Los síntomas y signos frecuentes son :

- Visión borrosa
- Visión doble
- Acercarse en exceso al plano de trabajo
- Guiñar o cierra un ojo con frecuencia
- Girar la cabeza o el cuerpo a la hora de escribir o leer
- Seguir la línea del texto con el dedo
- Invertir o confundir letras al leer o al escribir
- Dolor de cabeza

Pide una cita para una revisión visual completa ¡GRATIS!

// imagen GAFAS INDESTRUCTIBLES

// imagen GAFAS CON PROTECCIÓN FRENTE A LAS PANTALLAS ELECTRÓNICAS

Las monturas para niños no solo están influenciadas por la moda, tenemos que considerar que las gafas tienen que ser adecuadas para su defecto visual, su edad y su forma facial. Deben de ser resistentes a su ritmo de vida, no deben limitar ni su actividad diaria, ni su práctica deportiva.

En Centro Óptico auditivo Fausto de Torre del Mar encontrará monturas y gafas de sol infantiles de todos los materiales, tamaños, cómodas y  adaptadas a las necesidades de su hij@.

Ya que mencionamos el rendimiento académico, es importante revisar la vista y el oído de los niños antes de empezar el nuevo curso. En nuestra optica en Torre del Mar nos hemos encontrado con frecuencia que el niño no sabe que ve mal, y en consecuencia tiene dolores de cabeza o la visión cansada que afectan a la calidad de vida y de estudio.

Pasar una revisión permite localizar esas dolencias y prevenir su empeoramiento. De lo contrario pueden encontrarse con molestias a mitad de curso y padecer de problemas de audición o visión que se reflejen en sus notas. Ahora que tienes más tiempo (y que ellos tienen todo el día libre), lleva a tus hijos a los especialistas.

_______ <hr>
# 2.2.7 - Gafas Deportivas

## HERO - Estética,  protección  y funcionalidad en tus ojos

Para deportes de contacto: fútbol, baloncesto y deportes de raqueta, en los que diferentes elementos del juego, balones, pelotas, etc. suponen riesgos de lesiones oculares, las gafas de Protección Deportiva son un equipo de protección ocular indispensable durante la práctica deportiva. Homologadas y aprobadas por las principales Federaciones Deportivas, nuestras gafas deportivas ofrecen una solución visual para cada deportista.

## Gafas de natación y buceo
Disponibles sin y con graduación. (Miopía, hipermetropía, bifocales, etc)

Gafas de calidad óptica 100% fabricadas en policarbonato óptico, tratamiento anti-vaho  y protección UV  son de gran eficacia y resistencia.
_______ <hr>
# 3.0 - AUDICIÓN

## HERO - Porque ya basta de oír mal. 

Hay conversaciones que no queremos perdernos: la risa de un nieto, una charla de sobremesa, una canción que nos trae recuerdos. Cuando el oído empieza a fallar, no solo perdemos el sonido — perdemos trozos de esos momentos sin darnos cuenta, porque la pérdida auditiva suele llegar poco a poco.

Dar el paso de hacerse una revisión auditiva no es fácil, pero es el primer paso para volver a conectar con quienes más quieres. En Ópticas Fausto somos Centro Auditivo Homologado y llevamos 44 años, desde 1982, acompañando a las familias de Torre del Mar en este camino, sin prisas y sin presión.

[Pide tu estudio auditivo] [Llamada] [Whatsapp] 

## SERVICIOS DE AUDICIÓN

En nuestros centros disponemos del equipo y la experiencia necesarios para evaluar tu pérdida auditiva y recomendarte la solución que mejor se adapte a tus necesidades. Un diagnóstico a tiempo es la diferencia entre seguir esforzándote por entender lo que dicen los demás y volver a disfrutar de cada conversación sin esfuerzo.

*(lista de cards con elementos 3.1.x — imagen, título, descripción breve, [Ver más])*

## PRODUCTOS DE AUDICIÓN

Te asesoramos sobre los productos más adecuados para tu pérdida auditiva. Disponemos de una amplia gama de audífonos, desde el más sencillo hasta el más avanzado tecnológicamente. Nuestro equipo analizará tu caso y buscará la solución más óptima, tanto a nivel funcional como estético — y queremos que la pruebes en tu día a día antes de decidir, sin ningún compromiso.

*(lista de cards con elementos 3.2.x — imagen, título, descripción breve, [Ver más])*

[Pide tu cita] [Llamar] [WhatsApp]
_______<hr>
# 3.1.1 - Audiometría

## HERO Atentos a tu audición

En Fausto te conocemos. Nos acordamos de cuándo fue tu última revisión, de qué te dijimos entonces y de cómo ha evolucionado tu oído desde entonces. Por eso, cuando vienes a hacerte una audiometría, no empiezas de cero.

## ¿QUÉ ES UNA AUDIOMETRÍA?

Una audiometría es la prueba que mide con precisión cómo oyes: a qué volúmenes, en qué frecuencias y con qué claridad distingues las palabras. La realizamos en nuestra **cabina insonorizada**, con equipo audiométrico profesional, para garantizar un resultado fiable, sin interferencias del ruido exterior. Es indolora, no requiere preparación previa y se realiza y analiza en el mismo momento de la cita, sin necesidad de derivación médica.

## ¿PARA QUÉ SIRVE?

Una audiometría completa permite detectar a tiempo cualquier pérdida auditiva, por leve que sea, antes de que empiece a afectar a tu vida diaria — esas conversaciones a las que dejas de prestar atención porque cuesta seguirlas, o el volumen de la televisión que sube poco a poco sin que te des cuenta.

## LA IMPORTANCIA DEL DIAGNÓSTICO Y EL SEGUIMIENTO

El oído cambia con el tiempo, y muchas veces ese cambio es tan progresivo que cuesta notarlo desde dentro. Por eso recomendamos revisiones periódicas, no solo cuando ya hay una molestia evidente. Y si en algún momento necesitas una solución, nuestro equipo hace seguimiento real: no es una prueba aislada, es el primer paso de un acompañamiento que continúa en el tiempo.

[Pide tu estudio auditivo] [Llamar ahora]
_______<hr>
# 3.1.2 - Adaptación de audífonos en adultos y niños

## HERO - Volver a conectar con quienes más quieres

Decidir dar el paso hacia un audífono no siempre es fácil. Por eso, en Centro Auditivo Fausto queremos que estés totalmente satisfecho antes de comprometerte: lo usas, lo pruebas en tu día a día — en casa, en la calle, en una conversación real — y solo entonces decides, sin ningún compromiso.

## EL PROCESO, PASO A PASO

1. **Estudio auditivo completo en cabina insonorizada**, con equipo audiométrico profesional, para conocer con precisión el tipo y el grado de tu pérdida.
2. **Selección del audífono** que mejor se adapta a tus necesidades funcionales y estéticas, sea cual sea tu presupuesto.
3. **Prueba real, gratuita y sin compromiso.** Te lo llevas a casa para comprobar cómo te ayuda en tu vida diaria, no solo en una sala silenciosa.
4. **Ajuste personalizado**, afinando el audífono según tu feedback tras la prueba.
5. **Seguimiento continuado**, con revisiones periódicas para asegurarnos de que sigue funcionando como esperas, incluso años después de la compra.

## ADAPTACIÓN EN NIÑOS

La adaptación de audífonos en los más pequeños requiere especial sensibilidad y experiencia, tanto en el aspecto técnico como en el acompañamiento a la familia durante todo el proceso. En Fausto trabajamos de la mano de padres y madres para que esta etapa sea lo más sencilla y natural posible para el niño.

Pide tu cita [Llamada] [Whatsapp] 
_______ <hr>
# 3.1.3 - Tinnitus

En Centro Óptico Auditivo Fausto de Torre del Mar somos expertos en Terapia de Reentrenamiento de Tinnitus (Terapia TRT) y en la adaptación de audífonos para pérdidas auditivas y tinnitus.

El tinnitus, también llamado acúfeno, consiste en la percepción de ruidos o zumbidos en uno o ambos oídos que no proceden de ninguna fuente externa y solo los puede percibir la persona afectada. Existen muchos tipos diferentes de tinnitus, y varía considerablemente en intensidad y forma: algunas personas lo describen como sonidos silbantes o pitidos de alta frecuencia, otras como un zumbido continuo, y otras como una palpitación al ritmo del latido del corazón.

El tinnitus es más común entre personas que tienen pérdida de audición, aunque cualquiera puede padecerlo. Si tienes tinnitus y pérdida auditiva al mismo tiempo y empiezas a usar audífonos, descubrirás que estas prótesis pueden ayudarte tanto a mejorar tu audición como a reducir las molestias del tinnitus, así como la ansiedad y el estrés que suele provocar.

Pide tu cita [Llamada] [Whatsapp] 
_______ <hr>
# 3.1.4 - Mantenimiento de audífonos

## HERO - Manteniendo el mejor resultado

Un audífono bien cuidado dura más y funciona mejor. Por eso, en Ópticas Fausto el mantenimiento no termina el día que lo compras: seguimos aquí después, con equipo profesional, para que siga funcionando como el primer día.

## QUÉ INCLUYE NUESTRO SERVICIO DE MANTENIMIENTO

- **Limpieza y revisión técnica periódica**, con nuestro equipo profesional, en cualquiera de nuestros centros, sin necesidad de cita en la mayoría de los casos.
- **Cambio de filtros y olivas**, las piezas que más se desgastan con el uso diario.
- **Secado profesional con equipo especializado**, especialmente recomendado en la zona costera, donde la humedad ambiental afecta más a la electrónica del audífono.
- **Comprobación del estado de la pila o batería**, para detectar a tiempo cualquier pérdida de rendimiento antes de que te quedes sin sonido en el peor momento.
- **Diagnóstico técnico en cabina**, cuando el audífono necesita una revisión más a fondo, antes de derivarlo a reparación si fuera necesario.
- **Servicio urgente para turistas y visitantes**: si tu audífono falla durante tus vacaciones en Torre del Mar, te atendemos con prioridad para que no te quedes sin él en mitad del viaje.

Un buen mantenimiento alarga la vida útil de tu audífono y evita sorpresas. Si vienes a vernos, nosotros nos encargamos de todo el proceso técnico — tú solo tienes que traerlo.

Pide tu cita [Llamada] [Whatsapp] 
_______ <hr>
# 3.1.5 - Rehabilitación auditiva

## HERO

Ponerte un audífono es solo el primer paso. Aprender a sacarle el máximo partido —a volver a entender conversaciones en lugares ruidosos, a reconocer sonidos que llevabas tiempo sin oír— es un proceso, y en Fausto te acompañamos en él.

## ¿QUÉ ES LA REHABILITACIÓN AUDITIVA?

La rehabilitación auditiva es un conjunto de pautas y ejercicios que ayudan a tu cerebro a reaprender a interpretar los sonidos una vez que empiezas a usar el audífono. Tras un periodo de pérdida auditiva, el cerebro necesita tiempo para volver a procesar sonidos que llevaba tiempo sin recibir con claridad — por eso muchas personas notan que, al principio, "todo suena raro" o "demasiado fuerte".

## BENEFICIOS

- Adaptación más rápida y cómoda al audífono.
- Mejor comprensión del habla, especialmente en ambientes con ruido de fondo.
- Reducción de la fatiga auditiva que provoca el esfuerzo de escuchar sin ayuda.
- Mayor satisfacción a largo plazo con el uso del audífono.

## ¿CÓMO LO HACEMOS?

El proceso se apoya en revisiones periódicas en nuestra cabina insonorizada, donde comprobamos con audiometrías de control cómo evoluciona tu comprensión del habla a medida que avanzas. No es una sensación subjetiva: medimos el progreso con el mismo equipo técnico que usamos en el diagnóstico inicial, para ajustar el audífono y las pautas de entrenamiento a cómo responde realmente tu oído.

## UN COMPLEMENTO, NO UN SUSTITUTO

La rehabilitación auditiva no sustituye al audífono: lo complementa. Es el acompañamiento que marca la diferencia entre "tener un audífono" y "volver a oír bien de verdad" — y es parte del seguimiento que hacemos con cada cliente, no algo que termina el día de la compra.

Pide tu cita [Llamada] [Whatsapp] 
_______ <hr>
# 3.2.1 - Audífonos

## HERO - Un paso adelante para volver a conectar con quienes más quieres.

Los Centros Óptico Auditivo Fausto tienen certificación como Centro Auditivo Homologado.

Tenemos la solución para tu pérdida auditiva: disponemos de una amplia gama de audífonos, desde el más económico hasta el más sofisticado y con la última tecnología. Nuestro equipo especializado en audioprótesis evaluará tu pérdida auditiva para recomendarte el audífono que mejor se adapte a tus necesidades funcionales y estéticas.

Queremos que estés totalmente satisfecho con tu audífono: lo usas en tu vida diaria y lo pruebas antes de comprarlo, sin ningún compromiso.

Pide tu cita [Llamada] [Whatsapp] 

## Tipos de audífonos más utilizados:

### Retro auriculares.
Se colocan detrás de la oreja, consta de un molde, el cual se hace a la medida de su canal auditivo, están indicadas para personas con pérdidas leves, moderadas y severas.

### OPEN FIT
Son audífono retroauriculares pero con un tubo más fino y no llevan molde a medida sino una oliva que le da la ventaja de tener el oído abierto y son más cómodos y están indicados para personas con pérdidas leves y moderadas

### RITE
Son audífonos retroauriculares con tubo fino que tiene la particularidad de llevar el auricular dentro del conducto auditivo por lo que son más pequeños y estéticos y pueden adaptarse a pérdidas moderadas y severas.

### INTRACANAL
Son audífonos intrauriculares no llevan nada detrás del pabellón auditivos, van dentro del oído. Se fabrican en una carcasa personalizada que ocupa la cavidad auricular. Se utilizan para cubrir pérdidas leves, moderadas y severas, los hay de diferente tamaño.

// incorporo LANDING AUDICIÓN
[https://audicion.opticafausto.com/]{AUDICIÓN}

## Preguntas Frecuentes
¿Sospechas que puedes tener pérdida auditiva?
Quizá va siendo hora de revisar tu audición

¿Tienes que decir muchas veces…que, perdone,….?
¿Pones el volumen de la TV alto?
¿Con la mascarilla ha aumentado tu problema auditivo?

Si crees que tienes pérdida auditiva debes acudir a nuestro centro auditivo y hacerte una revisión, donde te atenderá un audioprotesista especializado, que te realizará las pruebas necesarias para saber qué tipo y cantidad de pérdida auditiva padeces y cuál es la mejor solución.

Si sospechas que la pérdida auditiva es a causa de una infección o algún problema que pueda ser tratado con medicamentos te derivará al médico otorrino

Pide tu cita [Llamada] [Whatsapp] 

A continuación, te explicamos que pruebas realizamos en nuestro centro para determinar el grado y tipo exacto de pérdida auditiva.

## ANAMNESIS
El audioprotesista te hará una serie de preguntas sobre tu estilo de vida, limitaciones durante el día a causa de la pérdida auditiva, historial clínico de tus oídos…

## OTOSCOPIA
Donde valorará si tienes alguna obstrucción por cera, si existe inflamación, o descartar cualquier impedimento para realizar la audiometría.

## AUDIOMETRÍA
Requiere la participación del paciente y no causa dolor. La audiometría consta de las siguientes pruebas:

### AUDIOMETRÍA TONAL AÉREA:
Mediante unos cascos el paciente tiene que decir cuándo empieza a escuchar el tono. Nos determina el estado del oído medio.

### AUDIOMETRÍA ÓSEA:
Mediante una diadema que se coloca sobre la mastoides el paciente debe decir cuando empieza a escuchar el tono. Nos da información sobre el estado del oído interno.

## LOGO AUDIOMETRÍA:
Mediante los cascos se reproduce una lista de palabras y el paciente tendrá que repetir lo que entienda. Es una prueba fundamental ya que nos da información sobre la calidad auditiva.

## UMBRAL DEL DOLOR:
Mediante unos cascos el paciente tendrá que decir hasta donde escucha el tono sin que le llegue a molestar. Esta prueba sirve para saber hasta dónde se puede amplificar sin que al paciente le moleste.


Una vez finalizadas estas pruebas se determinará si padeces pérdida auditiva, te informará cuál es tu problema y aconsejará sobre cuál es la mejor solución, la más estética, cómoda de manejar y que se adecue a tus necesidades.

_______ <hr>
# 3.2.2 - Ayudas Auditivas

## HERO - Una pequeña ayuda que hace una gran diferencia

Más allá del audífono, existen pequeñas ayudas técnicas que marcan una gran diferencia en el día a día: oír el despertador, disfrutar de la televisión sin subir el volumen al máximo, o saber cuándo suena el timbre. En Ópticas Fausto contamos con un catálogo de ayudas técnicas pensado para las situaciones más habituales de la vida cotidiana.

los números impactan

## DESPERTADORES CON VIBRACIÓN
Despertador digital con salida de voz y alarma de vibración bajo la almohada. Incluye pantalla LED grande con indicador de 24 horas.

## AURICULARES PARA OÍR LA TELEVISIÓN
Amplificador de televisión y música de manejo muy sencillo, alimentado por acumuladores recargables. Sus dos auriculares, próximos al oído, ofrecen una percepción espacial natural del sonido, con sistema limitador para mayor comodidad.

## TRANSMISORES
Transmisores de timbre, teléfono y conversación, para no perderte ninguna llamada ni visita.

## RECEPTOR DE BOLSILLO
Recibe las señales de los distintos transmisores del sistema y las muestra con claridad mediante luces y vibraciones. Pequeño, ligero y discreto, identifica cada aviso con un código de colores fácil de reconocer.

## PRODUCTOS PARA EL MANTENIMIENTO DE TU AUDÍFONO

- **Kit de limpieza**, para el cuidado diario del audífono.
- **Kit de secado**, especialmente recomendado en la zona costera por la humedad ambiental.
- **Comprobador de pilas**, para saber siempre cuánta carga te queda.
- **Pilas de Zinc-Aire**, de todos los tamaños, compatibles con la mayoría de audífonos del mercado.

¿Prefieres que nos encarguemos nosotros del mantenimiento? Consulta nuestro [servicio de mantenimiento de audífonos →].
_______ <hr>
# 3.2.3 Protectores de audición a medida

## HERO -  Protege tu descanso [o bien] Mejor protección, mejor audición, por más tiempo.

*(imagen: pareja en la cama, él roncando, ella sin poder dormir — o variante: alguien tapándose los oídos en un entorno ruidoso)*

Hay ruidos que no podemos evitar — el roncar de quien duerme a tu lado, el bullicio de un taller, el chapoteo de la piscina — pero sí podemos protegernos de ellos. Unos moldes a medida, fabricados según la forma exacta de tu oído, son mucho más cómodos y eficaces que cualquier tapón genérico de farmacia.

Pide tu cita [Llamada] [Whatsapp] 

## TAPONES ANTIRRUIDO

Moldes a medida, muy cómodos, que reducen tu nivel de audición en decibelios según tus necesidades. Si trabajas en espacios ruidosos, proteger el oído es clave para evitar una pérdida auditiva progresiva. También se utilizan para dormir mejor — ya sea por un entorno ruidoso o por los ronquidos de quien duerme a tu lado — o para concentrarte, por ejemplo al estudiar.

## MOLDES DE BAÑO

Fabricados a medida en silicona hipoalérgica, impiden la entrada de agua en el oído. Especialmente indicados para:

- Nadadores y bañistas habituales.
- Personas con otitis recurrentes, drenajes o perforaciones timpánicas.

Pide tu cita [Llamada] [Whatsapp] 

_______ <hr>
# 4.0 CONTACTO

## HERO

¿Tienes una duda, quieres pedir cita o necesitas que te ayudemos con algo urgente? Estamos a un mensaje, una llamada o una visita de distancia, en cualquiera de nuestros dos centros en Torre del Mar. Atendemos también en inglés y alemán — si estás de visita, ven sin cita previa si lo necesitas.

[Llamar] [WhatsApp] [Cómo llegar]

## Formulario de contacto

Nombre, teléfono y mensaje breve. Sin campos innecesarios.

**Información sobre protección de datos**

- **Responsable:** Ana Isabel Santaolalla Gámez.
- **Finalidad:** responder a tu solicitud de contacto.
- **Legitimación:** tu consentimiento al enviar el formulario.
- **Destinatarios:** tus datos se transmiten de forma cifrada a través de un proveedor de envío de correo electrónico (Resend), que actúa como encargado del tratamiento y no almacena los datos de forma permanente. No se ceden a ningún otro tercero.
- **Derechos:** puedes acceder, rectificar o suprimir tus datos, así como ejercer el resto de derechos reconocidos por la normativa, escribiendo a info@opticafausto.com.

☐ He leído y acepto la Política de Privacidad ([enlace]).

*(Sin checkbox de comunicaciones comerciales por email: el formulario solo se usa para responder a la consulta del usuario, no para añadirlo a listas de marketing. Si en el futuro se quiere usar para newsletter, añadir checkbox separado y opt-in explícito.)*

## Datos de contacto

**Centro Fausto Avenida**
Av. Andalucía, 84 B · Torre del Mar (29740) – Málaga
Teléfono: (+34) 952 54 09 64

**Centro Fausto Duque**
C/ Duque De Ahumada, 1C · Torre del Mar (29740) – Málaga
Teléfono: (+34) 952 54 70 90

**Común a ambos centros**
WhatsApp/Móvil: +34 717 77 00 90
Email: info@opticafausto.com
Horario: 10:00–13:30 y 17:00–20:30

<hr>
# o01 - 404

## Mensaje

¡Vaya! Parece que esta página no existe o se ha movido.

No te preocupes, desde aquí puedes volver a empezar:

[Ir a Inicio] [Ver Visión] [Ver Audición] 
[Llamada] [Whatsapp] 

*(Redirección automática a Inicio tras unos segundos, opcional)*

<hr>
# o02 - AVISO LEGAL

*(Nota de desarrollo: CIF y domicilio se ofuscarán en el desarrollo frontend mediante JS, para dificultar el scraping por bots — ver TO DO en proyecto-fausto-v09. El texto siguiente se publica con los datos reales; la ofuscación es una capa técnica añadida en implementación, no un cambio de contenido.)*

Esta página web es propiedad de Ana Isabel Santaolalla Gámez, con CIF [ofuscado en frontend] y domicilio en Duque de Ahumada, 1C, Torre del Mar (29740), Málaga.

Para cualquier consulta o propuesta, contacta con nosotros en info@opticafausto.com.

Esta página web se rige por la normativa aplicable en España, quedando sometidos a ella tanto los usuarios nacionales como extranjeros que la utilicen.

El acceso a nuestra página web es gratuito y está condicionado a la previa lectura y aceptación íntegra de las presentes Condiciones Generales de Uso. Al utilizar este portal, sus contenidos o servicios, el usuario acepta y se somete expresamente a estas condiciones. Si no estás de acuerdo, te pedimos que te abstengas de utilizar este sitio.

Podemos modificar en cualquier momento la presentación y configuración de la web, ampliar o reducir servicios, o incluso suprimirla, de forma unilateral y sin previo aviso.

## A. Propiedad intelectual

Todos los contenidos, textos, imágenes, marcas y código fuente de esta web son propiedad de Ópticas Fausto o de terceros de los que se han adquirido los derechos de explotación correspondientes, y están protegidos por la normativa de Propiedad Intelectual e Industrial.

El usuario tiene derecho a un uso privado y sin ánimo de lucro de estos contenidos, necesitando autorización expresa para modificarlos, reproducirlos, explotarlos o distribuirlos.

## B. Condiciones de acceso

El acceso a esta web es gratuito y no requiere registro previo. El envío de datos personales a través del formulario de contacto implica la aceptación expresa de nuestra Política de Privacidad.

El usuario debe acceder a esta web conforme a la buena fe y a las normas de orden público, siendo responsable de los daños y perjuicios que pudiera causar a terceros o a nosotros mismos por un uso indebido.

No nos hacemos responsables del contenido de páginas web de terceros a las que se pueda acceder mediante enlaces desde esta web.

## C. Política de privacidad

La confidencialidad y la seguridad de tus datos son un compromiso firme de Ópticas Fausto. Esta sección explica de forma clara cómo tratamos los datos personales que nos facilitas.

**1. Responsable del tratamiento:** Ana Isabel Santaolalla Gámez (ver datos en el encabezamiento de este Aviso Legal).

**2. Finalidad, legitimación y conservación de los datos enviados a través del formulario de contacto:**

- **Finalidad:** responder a tu solicitud de información o consulta. No utilizamos el formulario de contacto para enviarte comunicaciones comerciales salvo que lo solicites expresamente por otro medio.
- **Legitimación:** tu consentimiento, al enviar el formulario.
- **Conservación:** una vez resuelta tu consulta, tus datos se conservan únicamente el tiempo necesario para gestionarla, salvo que exista una obligación legal de conservación mayor.

El suministro de datos personales requiere una edad mínima de 14 años, o disponer de capacidad jurídica suficiente. Si no nos facilitas los datos solicitados (nombre, teléfono y mensaje), no podremos atender tu consulta.

**3. Destinatarios de tus datos.**

Tus datos se transmiten de forma cifrada a través de un proveedor de envío de correo electrónico (**Resend**), que actúa como encargado del tratamiento exclusivamente para hacernos llegar tu mensaje, y que no los almacena de forma permanente. No cedemos tus datos a ningún otro tercero, salvo obligación legal.

**4. Derechos en relación con tus datos personales.**

Puedes ejercer en cualquier momento tu derecho a:

- Acceder a tus datos personales o solicitar su rectificación si son inexactos.
- Solicitar su supresión cuando ya no sean necesarios para la finalidad por la que fueron recogidos.
- Solicitar la limitación de su tratamiento en determinadas circunstancias.
- Oponerte al tratamiento de tus datos.
- Solicitar la portabilidad de tus datos, cuando aplique.

Para ejercer estos derechos, escribe a info@opticafausto.com indicando la referencia "Datos Personales" y especificando el derecho que deseas ejercer. Si tienes alguna discrepancia con el tratamiento de tus datos, puedes presentar una reclamación ante la Agencia Española de Protección de Datos (www.aepd.es).

**5. Seguridad de tus datos personales.**

Hemos adoptado las medidas técnicas y organizativas necesarias para garantizar la seguridad de los datos personales que nos facilitas, evitando su alteración, pérdida o acceso no autorizado.

**6. Actualización de tus datos.**

Para mantener tus datos actualizados, te pedimos que nos informes si se produce alguna modificación en ellos. Esta Política de Privacidad puede actualizarse para adaptarse a cambios en la web o en la normativa aplicable.

## D. Responsabilidades

Ofrecemos esta web con la máxima diligencia posible, tanto en el servicio como en los medios tecnológicos utilizados. No obstante, no nos responsabilizamos de la presencia de virus u otros elementos que puedan dañar el sistema informático del usuario, ni garantizamos una disponibilidad continua e ininterrumpida del servicio.

Queda prohibida cualquier acción que origine una sobrecarga en nuestros sistemas informáticos, así como la introducción de virus o software que altere el funcionamiento normal de esta web.

El usuario asume la responsabilidad derivada del uso de esta página web y reconoce haber entendido y aceptado las presentes condiciones de uso.

<HR>

# o03 - POLÍTICA DE COOKIES

*(Nota de desarrollo: esta política refleja la Fase 1 del sitio, sin publicidad SEM ni píxeles de tracking. Ver bloque "Fase 2" al final de esta sección y el TO DO en proyecto-fausto-v09 — ap10 — para la versión ampliada que habrá que publicar cuando se active publicidad.)*

**Responsable:** Ana Isabel Santaolalla Gámez, con domicilio en C/ Duque de Ahumada, 1C, 29740 Torre del Mar.

## ¿Qué es una cookie?

Una cookie es un pequeño archivo que un sitio web puede guardar en tu navegador para recordar información sobre tu visita. Algunas cookies son necesarias para que la web funcione correctamente; otras se usan para analizar el comportamiento de los usuarios o para mostrar publicidad personalizada.

## Cookies que utiliza este sitio

**Actualmente, esta web no utiliza cookies de análisis, personalización ni publicidad.** No instalamos Google Analytics, píxeles de Meta/Facebook, ni ningún sistema de seguimiento de terceros. Por este motivo, no es necesario mostrar un banner de consentimiento de cookies: no hay nada que requiera tu autorización previa.

El sitio puede utilizar cookies técnicas estrictamente necesarias para su funcionamiento básico (por ejemplo, para recordar tu elección si rechazas o aceptas futuras cookies, cuando estas se incorporen). Estas cookies técnicas no requieren consentimiento según el artículo 22.2 de la LSSI-CE, al ser indispensables para prestar el servicio solicitado.

## Si en el futuro se incorporan cookies

Si en algún momento Ópticas Fausto decide activar campañas de publicidad en Google Ads o Meta (Instagram/Facebook Ads) con seguimiento de conversiones, o herramientas de analítica web, esta Política de Cookies se actualizará para detallar qué cookies se instalan, su finalidad, duración y titular, y se incorporará un banner de consentimiento previo a la carga de dichas cookies, permitiendo al usuario aceptarlas, rechazarlas o configurarlas de forma granular, conforme a la normativa vigente (RGPD y LSSI-CE).

## Cambios en esta política

Esta Política de Cookies puede modificarse para adaptarse a cambios en el sitio web o a nuevas exigencias legislativas. Cuando se produzcan cambios significativos, se comunicará al usuario en esta misma página.

<HR>



